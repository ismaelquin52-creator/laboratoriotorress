/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Shield, Key, Sparkles, Building2, UserCircle, RefreshCw, HelpCircle, Lock, X } from "lucide-react";

// Types
import { DecryptedLabRecord, DecryptedLabProfile, LabSettings } from "./types";

// Crypto
import { encryptData, decryptData, deriveAuthHash } from "./utils/crypto";

import { getAkoLogoBase64 } from "./utils/akoLogoSvg";

// Clinical & PDF utils
import { generateClinicalPDF } from "./utils/pdfGenerator";
import { CLINICAL_DEMO_RECORDS } from "./utils/demoData";

// Components
import LabAuth from "./components/LabAuth";
import LabProfileForm from "./components/LabProfileForm";
import ClinicalReportForm from "./components/ClinicalReportForm";
import ReportList from "./components/ReportList";
import PatientReceptionForm from "./components/PatientReceptionForm";
import Dashboard from "./components/Dashboard";

const DEFAULT_PROFILE: DecryptedLabProfile = {
  labName: "LABORATORIO CLÍNICO TORRES",
  address: "Calle 5 Oriente #41, Sección Ciudad Santa Ana, Santa Ana, Barrio San Rafael",
  phone: "74796040",
  email: "dricardo.torres23@gmail.com",
  customLogo: getAkoLogoBase64(), // Built-in official logo by default
  slogan: "Calidad y Precisión Diagnóstica",
  processedBy: "Dr. Ricardo Torres",
  processedByTitle: "Director Médico / Patólogo Clínico",
  processedByReg: "J.V.P.M. No. 12345",
  establishmentReg: "INSCRIPCIÓN CSSP 3085",
  reportFooter: "Este reporte de laboratorio clínico constituye un estudio de apoyo diagnóstico primario. Recomendamos que todo resultado sea evaluado, correlacionado e interpretado exclusivamente por su médico tratante.",
  themeColor: "blue",
  examPrices: {} // No default prices
};

export default function App() {
  const [labSettings, setLabSettings] = useState<LabSettings>({
    labId: "",
    passcode: "",
    isLoggedIn: false,
    derivedAuthHash: "",
    profile: { ...DEFAULT_PROFILE }
  });

  const [records, setRecords] = useState<DecryptedLabRecord[]>([]);
  const [isDemo, setIsDemo] = useState(false);
  const [currentUser, setCurrentUser] = useState<{ email: string; name: string; role: "general" | "ceo" | "gerente" } | null>(null);
  const [activeView, setActiveView] = useState<"auth" | "list" | "form" | "settings" | "reception" | "dashboard">("auth");
  const [currentEditingRecord, setCurrentEditingRecord] = useState<DecryptedLabRecord | null>(null);
  const [autoOpenVignetteForRecord, setAutoOpenVignetteForRecord] = useState<DecryptedLabRecord | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [globalError, setGlobalError] = useState("");
  const [showGlobalError, setShowGlobalError] = useState(true);

  // Auto-reveal banner whenever a new central sync message occurs
  useEffect(() => {
    if (globalError) {
      setShowGlobalError(true);
    }
  }, [globalError]);

  // Restore session from localStorage on startup (User Convenience)
  useEffect(() => {
    const cachedSettings = localStorage.getItem("labsync_settings_v1");
    const cachedDemoRecords = localStorage.getItem("labsync_records_demo_v1");
    const cachedUser = localStorage.getItem("labsync_current_user_v1");

    if (cachedUser) {
      try {
        const parsedUser = JSON.parse(cachedUser);
        setCurrentUser(parsedUser);

        if (cachedSettings) {
          const parsed = JSON.parse(cachedSettings) as LabSettings;
          setLabSettings(parsed);
          setIsDemo(false);
          setActiveView("list");
          
          // Fetch and decrypt online database
          syncOnlineDatabase(parsed.labId, parsed.passcode, parsed.derivedAuthHash);
        } else if (cachedDemoRecords) {
          const parsedRecords = JSON.parse(cachedDemoRecords) as DecryptedLabRecord[];
          setRecords(parsedRecords);
          setIsDemo(true);
          setActiveView("list");

          // Restore demo profile if exists
          const cachedDemoProfile = localStorage.getItem("labsync_profile_demo_v1");
          if (cachedDemoProfile) {
            const profile = JSON.parse(cachedDemoProfile) as DecryptedLabProfile;
            setLabSettings(prev => ({
              ...prev,
              isLoggedIn: true,
              isDemo: true,
              profile
            } as any));
          } else {
            setLabSettings(prev => ({
              ...prev,
              isLoggedIn: true,
              isDemo: true,
              profile: { ...DEFAULT_PROFILE }
            } as any));
          }
        } else {
          setActiveView("auth");
        }
      } catch (err) {
        console.warn("Could not parse cached session:", err);
        setActiveView("auth");
      }
    } else {
      setActiveView("auth");
    }
  }, []);

  // Primary function to fetch, decrypt, and load data from the synchronization node
  const syncOnlineDatabase = async (labId: string, passcode: string, authHash: string) => {
    setIsSyncing(true);
    setGlobalError("");
    
    try {
      const headers = {
        "x-lab-id": labId,
        "x-auth-hash": authHash
      };

      // 1. Fetch encrypted profile settings
      const profileRes = await fetch("/api/profile", { headers });
      if (profileRes.ok) {
        const profileData = await profileRes.json();
        if (profileData && profileData.encryptedProfile) {
          let decryptedProfileObj = null;
          try {
            decryptedProfileObj = await decryptData(profileData.encryptedProfile, passcode, labId);
          } catch {
            if (passcode.toLowerCase() !== "ako123456") {
              try {
                decryptedProfileObj = await decryptData(profileData.encryptedProfile, "ako123456", labId);
              } catch {}
            }
            if (!decryptedProfileObj && passcode.toUpperCase() !== "AKO12345") {
              try {
                decryptedProfileObj = await decryptData(profileData.encryptedProfile, "AKO12345", labId);
              } catch {}
            }
          }

          if (decryptedProfileObj) {
            setLabSettings(prev => ({
              ...prev,
              profile: decryptedProfileObj
            }));
            // Cache locally to enable robust offline/local fallback
            localStorage.setItem(`labsync_profile_${labId}_backup`, JSON.stringify(decryptedProfileObj));
          } else {
            console.warn("Profile decryption failed even with fallbacks. Resetting back to default profile...");
          }
        } else {
          // No profile saved on server yet, upload the default profile encrypted!
          const encryptedProfileStr = await encryptData(DEFAULT_PROFILE, passcode, labId);
          await fetch("/api/profile", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...headers
            },
            body: JSON.stringify({ encryptedProfile: encryptedProfileStr })
          });
        }
      } else {
        // Fallback to local profile cache if profile GET fails
        const cachedProfile = localStorage.getItem(`labsync_profile_${labId}_backup`);
        if (cachedProfile) {
          try {
            const parsed = JSON.parse(cachedProfile);
            setLabSettings(prev => ({
              ...prev,
              profile: parsed
            }));
          } catch {}
        }
      }

      // 2. Fetch encrypted patient files
      const recordsRes = await fetch("/api/records", { headers });
      if (!recordsRes.ok) {
        let errorMsg = "No se pudo descargar el registro de resultados.";
        try {
          const errPayload = await recordsRes.json();
          if (errPayload && errPayload.error) {
            errorMsg = errPayload.error;
          }
        } catch {}
        throw new Error(errorMsg);
      }

      const recordsData = await recordsRes.json();
      const serverRecords = recordsData.records || [];

      // Decrypt each record in-memory with intelligent key-fallback recovery
      const decryptedList: DecryptedLabRecord[] = [];
      
      for (const item of serverRecords) {
        let decObj = null;
        let lastDecError = null;

        // Try 1: Try current passcode
        try {
          decObj = await decryptData(item.encryptedData, passcode, labId);
        } catch (itemDecErr) {
          lastDecError = itemDecErr;
        }

        // Try 2: Try default fallback string if current is different
        if (!decObj && passcode.toLowerCase() !== "ako123456") {
          try {
            decObj = await decryptData(item.encryptedData, "ako123456", labId);
          } catch {}
        }

        // Try 3: Try explicit user password if current is different
        if (!decObj && passcode.toUpperCase() !== "AKO12345") {
          try {
            decObj = await decryptData(item.encryptedData, "AKO12345", labId);
          } catch {}
        }

        // Try 4: Try a fully lowercase version of user password if current is different
        if (!decObj && passcode.toLowerCase() !== "ako12345") {
          try {
            decObj = await decryptData(item.encryptedData, "ako12345", labId);
          } catch {}
        }

        if (decObj) {
          // Attach creation stamps
          decryptedList.push({
            ...decObj,
            id: item.id,
            createdAt: item.createdAt,
            updatedAt: item.updatedAt
          });
        } else {
          console.warn(`Skipped decryption of record ${item.id} due to key mismatch.`, lastDecError);
        }
      }

      // Sort by date descending
      decryptedList.sort((a, b) => new Date(b.examDate).getTime() - new Date(a.examDate).getTime());
      
      // Save local backup cache for robust offline survival on subsequent edits
      localStorage.setItem(`labsync_records_${labId}_backup`, JSON.stringify(decryptedList));
      setRecords(decryptedList);

    } catch (err: any) {
      console.warn("Sync failed, falling back to local client-side cache to protect user experience:", err);
      // Fallback: Restore client-side local backup if available so they see previous data
      const cachedBackup = localStorage.getItem(`labsync_records_${labId}_backup`);
      if (cachedBackup) {
        try {
          const parsed = JSON.parse(cachedBackup);
          setRecords(parsed);
        } catch {}
      }
      setGlobalError(err.message || "Fallo temporal al conectar con el servidor central.");
    } finally {
      setIsSyncing(false);
    }
  };

  // Event handlers
  const handleLoginSuccess = async (
    labId: string, 
    passcode: string, 
    user: { email: string; name: string; role: "general" | "ceo" | "gerente" }
  ) => {
    setIsDemo(false);
    setGlobalError("");
    setCurrentUser(user);
    localStorage.setItem("labsync_current_user_v1", JSON.stringify(user));
    
    try {
      const authHash = await deriveAuthHash(labId, passcode);
      const activeSettings: LabSettings = {
        labId,
        passcode,
        isLoggedIn: true,
        derivedAuthHash: authHash,
        profile: { 
          ...DEFAULT_PROFILE, 
          labName: "LABORATORIO CLÍNICO TORRES"
        }
      };

      setLabSettings(activeSettings);
      localStorage.setItem("labsync_settings_v1", JSON.stringify(activeSettings));
      localStorage.removeItem("labsync_records_demo_v1"); // clean demo variables

      setActiveView("list");
      
      // Perform initial cloud pull
      await syncOnlineDatabase(labId, passcode, authHash);
    } catch (err) {
      console.warn("Crypto derivation error:", err);
      setGlobalError("Fallo catastrófico al derivar claves criptográficas.");
    }
  };

  const handleEnterDemoMode = () => {
    setIsDemo(true);
    localStorage.removeItem("labsync_settings_v1");

    const demoUser = { email: "dricardo.torres23@gmail.com", name: "Dr. Ricardo Torres (Demo)", role: "general" as const };
    setCurrentUser(demoUser);
    localStorage.setItem("labsync_current_user_v1", JSON.stringify(demoUser));

    const cachedDemo = localStorage.getItem("labsync_records_demo_v1");
    if (cachedDemo) {
      try {
        setRecords(JSON.parse(cachedDemo));
      } catch {
        setRecords([]);
      }
    } else {
      // Preseed with realistic records
      setRecords(CLINICAL_DEMO_RECORDS);
      localStorage.setItem("labsync_records_demo_v1", JSON.stringify(CLINICAL_DEMO_RECORDS));
    }

    const demoProfile = { ...DEFAULT_PROFILE };
    setLabSettings({
      labId: "demo-local",
      passcode: "demo-local-secret",
      isLoggedIn: true,
      derivedAuthHash: "demo",
      profile: demoProfile
    });
    localStorage.setItem("labsync_profile_demo_v1", JSON.stringify(demoProfile));

    setActiveView("list");
  };

  const handleLogout = () => {
    localStorage.removeItem("labsync_settings_v1");
    localStorage.removeItem("labsync_records_demo_v1");
    localStorage.removeItem("labsync_profile_demo_v1");
    localStorage.removeItem("labsync_current_user_v1");
    
    setCurrentUser(null);
    setLabSettings({
      labId: "",
      passcode: "",
      isLoggedIn: false,
      derivedAuthHash: "",
      profile: { ...DEFAULT_PROFILE }
    });
    setRecords([]);
    setIsDemo(false);
    setActiveView("auth");
  };

  const handleSaveProfile = async (updatedProfile: DecryptedLabProfile) => {
    if (isDemo) {
      // Offline Local demo save
      setLabSettings(prev => {
        const update = { ...prev, profile: updatedProfile };
        localStorage.setItem("labsync_profile_demo_v1", JSON.stringify(updatedProfile));
        return update;
      });
      return;
    }

    // Cloud synchronized E2EE save
    try {
      const encryptedProfileStr = await encryptData(updatedProfile, labSettings.passcode, labSettings.labId);
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-lab-id": labSettings.labId,
          "x-auth-hash": labSettings.derivedAuthHash
        },
        body: JSON.stringify({ encryptedProfile: encryptedProfileStr })
      });

      if (!res.ok) {
        throw new Error("No se pudo guardar la configuración de membrete en el servidor.");
      }

      setLabSettings(prev => ({
        ...prev,
        profile: updatedProfile
      }));

      // Cache settings locally too to speed up next logins
      localStorage.setItem("labsync_settings_v1", JSON.stringify({
        ...labSettings,
        profile: updatedProfile
      }));
      localStorage.setItem(`labsync_profile_${labSettings.labId}_backup`, JSON.stringify(updatedProfile));

    } catch (err: any) {
      console.warn("Cloud profile save failed, using local caching to insulate experience:", err);
      // Fallback local persistence
      setLabSettings(prev => ({
        ...prev,
        profile: updatedProfile
      }));
      localStorage.setItem(`labsync_profile_${labSettings.labId}_backup`, JSON.stringify(updatedProfile));
      localStorage.setItem("labsync_settings_v1", JSON.stringify({
        ...labSettings,
        profile: updatedProfile
      }));
    }
  };

  const handleSaveRecord = async (decRecord: DecryptedLabRecord) => {
    if (activeView === "reception") {
      setAutoOpenVignetteForRecord(decRecord);
    }

    let finalRecord = { ...decRecord };
    
    // Doctor SV P2H Auto-Sync trigger (disabled)
    const shouldSync = false;

    if (shouldSync) {
      console.log("[P2H Auto Sync] Triggering automatic sync to Doctor SV...");
      finalRecord.p2hSyncStatus = "pending";
      
      try {
        const syncRes = await fetch("/api/p2h/sync", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-lab-id": labSettings.labId,
            "x-auth-hash": labSettings.derivedAuthHash
          },
          body: JSON.stringify({
            endpoint: labSettings.profile?.p2hEndpoint || "https://api.doctor.sv/v1/p2h/reports",
            token: labSettings.profile?.p2hToken,
            record: decRecord
          })
        });
        
        const syncData = await syncRes.json();
        if (syncRes.ok) {
          finalRecord.p2hSyncStatus = "success";
          finalRecord.p2hSyncedAt = new Date().toISOString();
          finalRecord.p2hErrorMessage = undefined;
          console.log("[P2H Auto Sync] Synchronization successful!");
        } else {
          finalRecord.p2hSyncStatus = "failed";
          finalRecord.p2hErrorMessage = syncData.error || "Fallo desconocido en P2H";
          console.warn("[P2H Auto Sync] Synchronization failed:", syncData.error);
        }
      } catch (err: any) {
        finalRecord.p2hSyncStatus = "failed";
        finalRecord.p2hErrorMessage = err.message || "Fallo de conexión en red P2H";
        console.warn("[P2H Auto Sync] Exception during sync:", err);
      }
    }

    if (isDemo) {
      // Local Demo array save
      let newList = [...records];
      const matchIndex = newList.findIndex(r => r.id === finalRecord.id);

      if (matchIndex > -1) {
        newList[matchIndex] = finalRecord;
      } else {
        newList.unshift(finalRecord);
      }

      setRecords(newList);
      localStorage.setItem("labsync_records_demo_v1", JSON.stringify(newList));
      setActiveView("list");
      return;
    }

    // Cloud synchronized E2EE save
    try {
      const encryptedDataStr = await encryptData(finalRecord, labSettings.passcode, labSettings.labId);
      
      const res = await fetch("/api/records", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-lab-id": labSettings.labId,
          "x-auth-hash": labSettings.derivedAuthHash
        },
        body: JSON.stringify({
          id: finalRecord.id,
          encryptedData: encryptedDataStr
        })
      });

      if (!res.ok) {
        throw new Error("No se pudo guardar ni sincronizar el registro.");
      }

      // Re-trigger database pull to guarantee consistency
      await syncOnlineDatabase(labSettings.labId, labSettings.passcode, labSettings.derivedAuthHash);
      setActiveView("list");

    } catch (err: any) {
      console.warn("Cloud save failed, falling back to local fallback to protect user data:", err);
      
      // PERSIST LOCALLY FOR REGISTERED LAB (Offline survival & local backup mode)
      let newList = [...records];
      const matchIndex = newList.findIndex(r => r.id === finalRecord.id);
      
      const updatedRecord = {
        ...finalRecord,
        updatedAt: new Date().toISOString()
      };
      
      if (matchIndex > -1) {
        newList[matchIndex] = updatedRecord;
      } else {
        newList.unshift(updatedRecord);
      }
      
      setRecords(newList);
      
      // Cache locally
      localStorage.setItem(`labsync_records_${labSettings.labId}_backup`, JSON.stringify(newList));
      setGlobalError("Fallo de conexión al servidor. Se han guardado tus cambios localmente en este navegador. Puedes seguir consultando, registrando resultados y descargando tus PDFs sin problemas.");
      setActiveView("list");
    }
  };

  const handleDeleteRecord = async (recordId: string) => {
    if (isDemo) {
      // Local demo array delete
      const updated = records.filter(r => r.id !== recordId);
      setRecords(updated);
      localStorage.setItem("labsync_records_demo_v1", JSON.stringify(updated));
      return;
    }

    // Cloud delete
    try {
      const res = await fetch(`/api/records/${recordId}`, {
        method: "DELETE",
        headers: {
          "x-lab-id": labSettings.labId,
          "x-auth-hash": labSettings.derivedAuthHash
        }
      });

      if (!res.ok) {
        throw new Error("Fallo al eliminar el registro en la nube.");
      }

      setRecords(prev => prev.filter(r => r.id !== recordId));
    } catch (err: any) {
      console.warn("Delete cloud record error:", err);
      throw err;
    }
  };

  const handleDownloadPDF = (
    record: DecryptedLabRecord,
    targetExamId?: string,
    targetExamName?: string,
    chemistryLayout?: "compact" | "continuous" | "individual",
    action: "download" | "print" = "download"
  ) => {
    try {
      const pdf = generateClinicalPDF(record, labSettings.profile, targetExamId, chemistryLayout);
      const safeName = record.patientName.trim().toLowerCase().replace(/[^a-z0-9]/g, "_");
      let suffix = "";
      if (targetExamName) {
        suffix = `_${targetExamName.trim().toLowerCase().replace(/[^a-z0-9]/g, "_")}`;
      } else if (chemistryLayout) {
        suffix = `_quimicas_${chemistryLayout}`;
      }

      if (action === "print") {
        const blob = pdf.output("blob");
        const blobUrl = URL.createObjectURL(blob);
        const newWindow = window.open(blobUrl, "_blank");
        if (newWindow) {
          newWindow.focus();
        } else {
          pdf.save(`Resultado_Lab_${safeName}${suffix}.pdf`);
          alert("La ventana emergente para imprimir fue bloqueada por el navegador. El archivo PDF se ha descargado de forma automática.");
        }
      } else {
        pdf.save(`Resultado_Lab_${safeName}${suffix}.pdf`);
      }
    } catch (err) {
      console.warn("PDF operation failed:", err);
      alert("Error al generar el archivo de reporte PDF.");
    }
  };

  const handleLoadDemoData = () => {
    setRecords(CLINICAL_DEMO_RECORDS);
    localStorage.setItem("labsync_records_demo_v1", JSON.stringify(CLINICAL_DEMO_RECORDS));
  };

  const handleManualSync = async () => {
    await syncOnlineDatabase(labSettings.labId, labSettings.passcode, labSettings.derivedAuthHash);
  };

  const handleSyncRecordToP2H = async (recordId: string) => {
    const recordIdx = records.findIndex(r => r.id === recordId);
    if (recordIdx === -1) return;

    const record = records[recordIdx];
    let finalRecord = { ...record, p2hSyncStatus: "pending" as const };

    // Update state immediately to show spinner
    const pendingList = [...records];
    pendingList[recordIdx] = finalRecord;
    setRecords(pendingList);

    try {
      const syncRes = await fetch("/api/p2h/sync", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-lab-id": labSettings.labId,
          "x-auth-hash": labSettings.derivedAuthHash
        },
        body: JSON.stringify({
          endpoint: labSettings.profile?.p2hEndpoint || "https://api.doctor.sv/v1/p2h/reports",
          token: labSettings.profile?.p2hToken,
          record
        })
      });

      const syncData = await syncRes.json();
      if (syncRes.ok) {
        finalRecord.p2hSyncStatus = "success";
        finalRecord.p2hSyncedAt = new Date().toISOString();
        finalRecord.p2hErrorMessage = undefined;
      } else {
        finalRecord.p2hSyncStatus = "failed";
        finalRecord.p2hErrorMessage = syncData.error || "Fallo desconocido en P2H";
      }

      // Persist the updated status
      if (isDemo) {
        const updatedList = [...records];
        updatedList[recordIdx] = finalRecord;
        setRecords(updatedList);
        localStorage.setItem("labsync_records_demo_v1", JSON.stringify(updatedList));
      } else {
        const encryptedDataStr = await encryptData(finalRecord, labSettings.passcode, labSettings.labId);
        await fetch("/api/records", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-lab-id": labSettings.labId,
            "x-auth-hash": labSettings.derivedAuthHash
          },
          body: JSON.stringify({
            id: finalRecord.id,
            encryptedData: encryptedDataStr
          })
        });
        await syncOnlineDatabase(labSettings.labId, labSettings.passcode, labSettings.derivedAuthHash);
      }
    } catch (err: any) {
      console.error("Manual P2H Sync failed:", err);
      finalRecord.p2hSyncStatus = "failed";
      finalRecord.p2hErrorMessage = err.message || "Fallo de conexión";
      
      const updatedList = [...records];
      updatedList[recordIdx] = finalRecord;
      setRecords(updatedList);
    }
  };

  // Switch View controllers
  const renderContentView = () => {
    switch (activeView) {
      case "list":
        return (
          <ReportList
            records={records}
            autoOpenVignette={autoOpenVignetteForRecord}
            onClearAutoOpenVignette={() => setAutoOpenVignetteForRecord(null)}
            onAddRecord={() => {
              setCurrentEditingRecord(null);
              setActiveView("form");
            }}
            onEditRecord={(record) => {
              setCurrentEditingRecord(record);
              setActiveView("form");
            }}
            onDeleteRecord={handleDeleteRecord}
            onDownloadPDF={handleDownloadPDF}
            onOpenSettings={() => setActiveView("settings")}
            onLogout={handleLogout}
            onLoadDemoData={handleLoadDemoData}
            labId={labSettings.labId}
            isDemo={isDemo}
            onSync={handleManualSync}
            isSyncing={isSyncing}
            userRole={currentUser?.role}
            onSyncP2H={handleSyncRecordToP2H}
            p2hEnabled={labSettings.profile?.p2hEnabled}
          />
        );
      case "form":
        return (
          <ClinicalReportForm
            initialRecord={currentEditingRecord}
            onSave={handleSaveRecord}
            onDownloadPDF={handleDownloadPDF}
            onCancel={() => {
              setCurrentEditingRecord(null);
              setActiveView("list");
            }}
            profile={labSettings.profile}
            records={records}
          />
        );
      case "settings":
        return (
          <LabProfileForm
            initialProfile={labSettings.profile}
            onSaveProfile={handleSaveProfile}
            onCancel={() => setActiveView("list")}
          />
        );
      case "reception":
        return (
          <PatientReceptionForm
            profile={labSettings.profile}
            onSave={handleSaveRecord}
            onCancel={() => setActiveView("list")}
          />
        );
      case "dashboard":
        return (
          <Dashboard
            records={records}
            onBack={() => setActiveView("list")}
          />
        );
      default:
        return null;
    }
  };

  // If not logged in, render the login shield first
  if (activeView === "auth" || !labSettings.isLoggedIn) {
    return (
      <LabAuth
        onLoginSuccess={handleLoginSuccess}
        onEnterDemoMode={handleEnterDemoMode}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pt-0 pb-12 font-sans overflow-y-auto" id="app-main-layout">
      {/* Visual Navigation Header Banner */}
      <nav className="bg-[#1e293b] text-white shadow-md border-b border-indigo-950/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo and sync badge */}
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-tr from-teal-400 to-emerald-500 p-1.5 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-slate-950" />
              </div>
              <span className="font-extrabold text-xs sm:text-sm tracking-tight uppercase">
                <span className="text-emerald-400 font-extrabold">LABORATORIO CLÍNICO TORRES</span>
              </span>
              <span className="h-4 w-px bg-slate-700 hidden sm:inline" />
              
              <div className="hidden md:flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300 max-w-[140px] truncate">
                  {labSettings.profile.labName}
                </span>
                
                {isDemo ? (
                  <span className="inline-flex items-center text-[9px] bg-amber-500/10 border border-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full font-bold">
                    Demo
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[9px] bg-emerald-500/10 border border-emerald-500/20 text-teal-400 px-2 py-0.5 rounded-full font-bold">
                    Cifrado
                  </span>
                )}
              </div>
            </div>

            {/* Navigation Modes Trigger Widget */}
            <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 shadow-inner">
              <button
                type="button"
                onClick={() => setActiveView("list")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeView === "list" || activeView === "form" ? "bg-teal-650 text-white shadow-md font-extrabold" : "text-slate-300 hover:text-white"}`}
              >
                🔬 Laboratorio
              </button>
              <button
                type="button"
                onClick={() => {
                  setCurrentEditingRecord(null);
                  setActiveView("reception");
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeView === "reception" ? "bg-teal-650 text-white shadow-md font-extrabold" : "text-slate-300 hover:text-white"}`}
              >
                📥 Recepción
              </button>
              <button
                type="button"
                onClick={() => setActiveView("dashboard")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${activeView === "dashboard" ? "bg-teal-650 text-white shadow-md font-extrabold" : "text-slate-300 hover:text-white"}`}
              >
                📈 Estadísticas
              </button>
            </div>

            {/* Sync trigger & connection status */}
            <div className="flex items-center gap-3">
              {!isDemo && (
                <button
                  type="button"
                  disabled={isSyncing}
                  onClick={handleManualSync}
                  className="flex items-center justify-center h-8.5 w-8.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-750 rounded-xl transition-all cursor-pointer disabled:opacity-50"
                  title="Resincronizar base cifrada"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? "animate-spin" : ""}`} />
                </button>
              )}
              
              <div className="flex items-center gap-2 text-slate-300 pl-2">
                <UserCircle className="w-5 h-5 text-teal-400" />
                <span className="text-xs font-bold font-mono tracking-wide max-w-28 truncate capitalize">
                  {labSettings.labId}
                </span>
              </div>
            </div>

          </div>
        </div>
      </nav>

      {/* Global alert block if server fails */}
      {globalError && showGlobalError && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-5 w-full">
          <div className="bg-amber-950/25 border border-amber-700/40 rounded-xl p-3.5 text-xs text-amber-400 font-semibold flex items-start justify-between gap-2.5">
            <div className="flex gap-2.5 items-start">
              <Lock className="w-5 h-5 text-amber-550 shrink-0 mt-0.5 animate-bounce" />
              <div className="leading-normal">
                <span className="font-bold text-amber-300">Modo de Respaldo Local Activado:</span> {globalError} Sin embargo, puedes seguir reportando y descargando tus PDFs temporalmente sin perder cambios.
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowGlobalError(false)}
              className="text-amber-400/70 hover:text-amber-300 p-1 rounded-lg hover:bg-amber-900/10 cursor-pointer transition-all self-start"
              title="Cerrar advertencia"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Primary Workspace Stage */}
      <main className="flex-grow pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {renderContentView()}
        </div>
      </main>

    </div>
  );
}
