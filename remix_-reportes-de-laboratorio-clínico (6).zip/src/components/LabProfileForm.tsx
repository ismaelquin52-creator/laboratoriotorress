import React, { useState, useRef, useEffect } from "react";
import { Building2, MapPin, Phone, Mail, FileText, Upload, Trash2, Save, ArrowLeft, CheckCircle2, ShieldCheck, Search, Sliders, Link, Unlink } from "lucide-react";
import { DecryptedLabProfile } from "../types";
import { AVAILABLE_EXAMS } from "./PatientReceptionForm";
import DatabaseDiagnostics from "./DatabaseDiagnostics";

interface LabProfileFormProps {
  initialProfile: DecryptedLabProfile;
  onSaveProfile: (profile: DecryptedLabProfile) => Promise<void>;
  onCancel: () => void;
}

export default function LabProfileForm({ initialProfile, onSaveProfile, onCancel }: LabProfileFormProps) {
  const [labName, setLabName] = useState(initialProfile.labName || "");
  const [address, setAddress] = useState(initialProfile.address || "");
  const [phone, setPhone] = useState(initialProfile.phone || "");
  const [email, setEmail] = useState(initialProfile.email || "");
  const [reportFooter, setReportFooter] = useState(initialProfile.reportFooter || "");
  const [logoBase64, setLogoBase64] = useState(initialProfile.customLogo || "");
  const [slogan, setSlogan] = useState(initialProfile.slogan || "");
  const [processedBy, setProcessedBy] = useState(initialProfile.processedBy || "");
  const [processedByTitle, setProcessedByTitle] = useState(initialProfile.processedByTitle || "");
  const [processedByReg, setProcessedByReg] = useState(initialProfile.processedByReg || "");
  const [labSeal, setLabSeal] = useState(initialProfile.labSeal || "");
  const [signatureSeal, setSignatureSeal] = useState(initialProfile.signatureSeal || "");
  const [themeColor, setThemeColor] = useState(initialProfile.themeColor || "navy");
  const [establishmentReg, setEstablishmentReg] = useState(initialProfile.establishmentReg || "INSCRIPCIÓN CSSP 3085");

  // Doctor SV P2H Integration State
  const [p2hEnabled, setP2hEnabled] = useState<boolean>(initialProfile.p2hEnabled || false);
  const [p2hToken, setP2hToken] = useState<string>(initialProfile.p2hToken || "");
  const [p2hEndpoint, setP2hEndpoint] = useState<string>(initialProfile.p2hEndpoint || "https://api.doctor.sv/v1/p2h/reports");
  const [p2hOnlyDoctorSV, setP2hOnlyDoctorSV] = useState<boolean>(initialProfile.p2hOnlyDoctorSV ?? true);

  const [sigWidth, setSigWidth] = useState<number>(initialProfile.sigWidth ?? 45);
  const [sigHeight, setSigHeight] = useState<number>(initialProfile.sigHeight ?? 14);
  const [sigXOffset, setSigXOffset] = useState<number>(initialProfile.sigXOffset ?? 0);
  const [sigYOffset, setSigYOffset] = useState<number>(initialProfile.sigYOffset ?? 0);

  const [sealWidth, setSealWidth] = useState<number>(initialProfile.sealWidth ?? 25);
  const [sealHeight, setSealHeight] = useState<number>(initialProfile.sealHeight ?? 25);
  const [sealXOffset, setSealXOffset] = useState<number>(initialProfile.sealXOffset ?? 0);
  const [sealYOffset, setSealYOffset] = useState<number>(initialProfile.sealYOffset ?? 0);

  // Aspect ratio states for proportional locking
  const [sigRatio, setSigRatio] = useState<number | null>(null);
  const [sealRatio, setSealRatio] = useState<number | null>(null);
  const [lockSigRatio, setLockSigRatio] = useState<boolean>(true);
  const [lockSealRatio, setLockSealRatio] = useState<boolean>(true);

  // Read actual image dimensions to lock natural aspect ratios on load
  useEffect(() => {
    if (initialProfile.signatureSeal) {
      const img = new Image();
      img.onload = () => {
        setSigRatio(img.width / img.height);
      };
      img.src = initialProfile.signatureSeal;
    }
    if (initialProfile.labSeal) {
      const img = new Image();
      img.onload = () => {
        setSealRatio(img.width / img.height);
      };
      img.src = initialProfile.labSeal;
    }
  }, [initialProfile.signatureSeal, initialProfile.labSeal]);

  const handleSigWidthChange = (val: number) => {
    setSigWidth(val);
    if (lockSigRatio && sigRatio) {
      const targetHeight = Math.round((val / sigRatio) * 10) / 10;
      setSigHeight(targetHeight || 1);
    }
  };

  const handleSigHeightChange = (val: number) => {
    setSigHeight(val);
    if (lockSigRatio && sigRatio) {
      const targetWidth = Math.round((val * sigRatio) * 10) / 10;
      setSigWidth(targetWidth || 1);
    }
  };

  const handleSealWidthChange = (val: number) => {
    setSealWidth(val);
    if (lockSealRatio && sealRatio) {
      const targetHeight = Math.round((val / sealRatio) * 10) / 10;
      setSealHeight(targetHeight || 1);
    }
  };

  const handleSealHeightChange = (val: number) => {
    setSealHeight(val);
    if (lockSealRatio && sealRatio) {
      const targetWidth = Math.round((val * sealRatio) * 10) / 10;
      setSealWidth(targetWidth || 1);
    }
  };
  const [examPrices, setExamPrices] = useState<Record<string, number>>(
    initialProfile.examPrices || {
      hemograma: 8,
      ego: 2,
      heces: 2,
      quimica_basica: 3,
      perfil_lipidico: 3,
      perfil_hepatico: 4,
      funcion_renal: 3,
      urocultivo: 10,
      coprocultivo: 10,
      cultivo_faringeo: 10,
      secreciones_varias: 10,
      espermograma: 35,
      miscelaneo: 6
    }
  );
  const [showIndividualPrices, setShowIndividualPrices] = useState(false);
  const [priceSearchQuery, setPriceSearchQuery] = useState("");

  const [isSaving, setIsSaving] = useState(false);
  const [errorStatus, setErrorStatus] = useState("");
  const [successStatus, setSuccessStatus] = useState(false);

  // USERS MANAGEMENT FOR SCIENTIFIC CLINICAL ACCOUNTS
  const [usersList, setUsersList] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("labsync_users_v1");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    const defaultSeed = [
      { email: "admin@akolab.com", password: "ako123", name: "Administrador General", role: "general" },
      { email: "ceo@akolab.com", password: "ceo123", name: "Licda. Ana Kely Ortéz (CEO)", role: "ceo" },
      { email: "gerente@akolab.com", password: "gerente123", name: "Gerencia de Operaciones (Gerente)", role: "gerente" }
    ];
    localStorage.setItem("labsync_users_v1", JSON.stringify(defaultSeed));
    return defaultSeed;
  });

  const [newUserName, setNewUserName] = useState("");
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [newUserRole, setNewUserRole] = useState<"general" | "ceo" | "gerente">("general");
  const [userAdminError, setUserAdminError] = useState("");
  const [userAdminSuccess, setUserAdminSuccess] = useState("");

  const handleAddNewUser = () => {
    setUserAdminError("");
    setUserAdminSuccess("");

    if (!newUserName.trim()) {
      setUserAdminError("Por favor ingrese el nombre completo del usuario.");
      return;
    }
    if (!newUserEmail.trim() || !newUserEmail.includes("@")) {
      setUserAdminError("Por favor ingrese un correo electrónico válido.");
      return;
    }
    if (!newUserPassword.trim() || newUserPassword.length < 4) {
      setUserAdminError("La contraseña debe tener al menos 4 caracteres.");
      return;
    }

    if (usersList.some(u => u.email.toLowerCase() === newUserEmail.toLowerCase().trim())) {
      setUserAdminError("Ya existe un usuario científico registrado con este correo.");
      return;
    }

    const newUser = {
      email: newUserEmail.toLowerCase().trim(),
      password: newUserPassword.trim(),
      name: newUserName.trim(),
      role: newUserRole
    };

    const updatedList = [...usersList, newUser];
    setUsersList(updatedList);
    localStorage.setItem("labsync_users_v1", JSON.stringify(updatedList));

    setNewUserName("");
    setNewUserEmail("");
    setNewUserPassword("");
    setNewUserRole("general");
    setUserAdminSuccess(`¡Éxito! El usuario "${newUser.name}" fue creado exitosamente.`);
    setTimeout(() => setUserAdminSuccess(""), 4000);
  };

  const handleDeleteUser = (emailToDelete: string) => {
    setUserAdminError("");
    setUserAdminSuccess("");

    if (emailToDelete.toLowerCase() === "admin@akolab.com") {
      setUserAdminError("Por motivos de seguridad, no se puede eliminar la cuenta maestra.");
      return;
    }

    const updatedList = usersList.filter(u => u.email.toLowerCase() !== emailToDelete.toLowerCase());
    setUsersList(updatedList);
    localStorage.setItem("labsync_users_v1", JSON.stringify(updatedList));
    setUserAdminSuccess("El usuario científico ha sido eliminado.");
    setTimeout(() => setUserAdminSuccess(""), 3500);
  };
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sealInputRef = useRef<HTMLInputElement>(null);
  const signatureInputRef = useRef<HTMLInputElement>(null);

  // Resize and compress uploaded images using Canvas to save DB storage space
  const compressAndSet = (
    file: File, 
    callback: (base64: string, w: number, h: number) => void, 
    maxWidth = 250, 
    maxHeight = 100
  ) => {
    if (!file.type.match("image.*")) {
      setErrorStatus("La carga debe ser una imagen válida (PNG, JPG, JPEG).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width / height > maxWidth / maxHeight) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL("image/png", 0.85);
          callback(compressed, width, height);
          setErrorStatus("");
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    compressAndSet(file, (base64) => setLogoBase64(base64), 300, 120);
  };

  const handleLabSealUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    compressAndSet(file, (base64, w, h) => {
      setLabSeal(base64);
      const ratio = w / h;
      setSealRatio(ratio);
      setSealWidth(25);
      setSealHeight(Math.round((25 / ratio) * 10) / 10);
    }, 200, 200); // Seals are usually square
  };

  const handleSignatureSealUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    compressAndSet(file, (base64, w, h) => {
      setSignatureSeal(base64);
      const ratio = w / h;
      setSigRatio(ratio);
      setSigWidth(45);
      setSigHeight(Math.round((45 / ratio) * 10) / 10);
    }, 240, 100); // Signatures are wider
  };

  const removeLogo = () => {
    setLogoBase64("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeLabSeal = () => {
    setLabSeal("");
    if (sealInputRef.current) sealInputRef.current.value = "";
  };

  const removeSignatureSeal = () => {
    setSignatureSeal("");
    if (signatureInputRef.current) signatureInputRef.current.value = "";
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!labName.trim()) {
      setErrorStatus("El nombre del laboratorio es mandatorio.");
      return;
    }

    setIsSaving(true);
    setErrorStatus("");
    setSuccessStatus(false);

    try {
      await onSaveProfile({
        labName: labName.trim(),
        address: address.trim(),
        phone: phone.trim(),
        email: email.trim(),
        customLogo: logoBase64,
        reportFooter: reportFooter.trim(),
        slogan: slogan.trim(),
        processedBy: processedBy.trim(),
        processedByTitle: processedByTitle.trim(),
        processedByReg: processedByReg.trim(),
        establishmentReg: establishmentReg.trim(),
        labSeal: labSeal,
        signatureSeal: signatureSeal,
        themeColor,
        examPrices,
        sigWidth,
        sigHeight,
        sigXOffset,
        sigYOffset,
        sealWidth,
        sealHeight,
        sealXOffset,
        sealYOffset,
        p2hEnabled,
        p2hToken: p2hToken.trim(),
        p2hEndpoint: p2hEndpoint.trim(),
        p2hOnlyDoctorSV
      });
      setSuccessStatus(true);
      setTimeout(() => setSuccessStatus(false), 3000);
    } catch (err: any) {
      setErrorStatus(err.message || "No se pudo sincronizar el perfil.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-6 px-4" id="lab-profile-container">
      {/* Back banner */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-200">
        <button
          onClick={onCancel}
          className="flex items-center text-sm font-medium text-slate-600 hover:text-slate-950 transition-colors gap-2 cursor-pointer focus:outline-none"
          id="profile-back-btn"
        >
          <ArrowLeft className="w-4 h-4" /> Volver al Tablero
        </button>
        <div className="flex items-center text-xs text-slate-500 gap-1.5 font-medium bg-slate-100 px-3 py-1.5 rounded-full">
          <ShieldCheck className="w-4 h-4 text-emerald-600" /> Sincronización Protegida
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Banner header */}
        <div className="bg-slate-550 bg-gradient-to-tr from-slate-800 to-indigo-900 px-6 py-5 text-white">
          <h2 className="text-xl font-bold font-sans">Configuración Personalizada del Laboratorio</h2>
          <p className="text-slate-300 text-xs mt-1 leading-relaxed">
            Personaliza el membrete oficial, información de contacto, logo y pie de página que se incluirá en cada PDF (Boleta de Resultados) automático.
          </p>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-6" id="lab-profile-form">
          {/* Logo Upload Section */}
          <div className="space-y-3">
            <label className="block text-sm font-semibold text-slate-850">Logo de Boleta Oficial</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
              <div className="md:col-span-2 space-y-2">
                <p className="text-xs text-slate-500 leading-normal">
                  Carga un logo para que aparezca elegantemente alineado en el informe PDF. Se recomienda un logo apaisado con fondo claro o transparente. Máxima resolución reducida automáticamente.
                </p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-4 py-2 border border-slate-300 text-slate-700 rounded-xl hover:bg-slate-50 text-xs font-semibold cursor-pointer transition-all"
                    id="trigger-logo-upload-btn"
                  >
                    <Upload className="w-4 h-4 text-slate-500" /> Cargar Fotografía
                  </button>
                  {logoBase64 && (
                    <button
                      type="button"
                      onClick={removeLogo}
                      className="flex items-center gap-2 px-3 py-2 border border-red-200 text-red-600 hover:bg-red-50 rounded-xl text-xs font-semibold cursor-pointer transition-all"
                      id="remove-logo-btn"
                    >
                      <Trash2 className="w-4 h-4" /> Eliminar
                    </button>
                  )}
                </div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleLogoUpload}
                  accept="image/png, image/jpeg, image/jpg"
                  className="hidden"
                />
              </div>

              {/* Logo Preview box */}
              <div className="border border-dashed border-slate-300 bg-slate-50 rounded-2xl h-28 flex items-center justify-center p-3 overflow-hidden relative group">
                {logoBase64 ? (
                  <img
                    src={logoBase64}
                    alt="Lab Logo Preview"
                    className="max-w-full max-h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="text-center text-slate-400">
                    <Building2 className="w-8 h-8 mx-auto mb-1 stroke-1 text-slate-300" />
                    <span className="text-[10px] uppercase font-bold tracking-wider">Sin Logo Personalizado</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Core Info Inputs Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Nombre Oficial del Laboratorio
              </label>
              <div className="relative rounded-xl shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <Building2 className="h-4.5 w-4.5 text-slate-400" />
                </div>
                <input
                  type="text"
                  required
                  placeholder="ej. Laboratorio Clínico Central"
                  value={labName}
                  onChange={(e) => setLabName(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Número Telefónico
              </label>
              <div className="relative rounded-xl shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <Phone className="h-4.5 w-4.5 text-slate-400" />
                </div>
                <input
                  type="text"
                  placeholder="+503 2235-0000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Dirección Física del Laboratorio
              </label>
              <div className="relative rounded-xl shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <MapPin className="h-4.5 w-4.5 text-slate-400" />
                </div>
                <input
                  type="text"
                  placeholder="Avenida General Escalon, No 23A, San Salvador"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Eslogan o Subtítulo del Membrete
              </label>
              <div className="relative rounded-xl shadow-sm">
                <input
                  type="text"
                  placeholder="ej. Innovación y Precisión al servicio de su salud"
                  value={slogan}
                  onChange={(e) => setSlogan(e.target.value)}
                  className="block w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Correo Electrónico de Contacto
              </label>
              <div className="relative rounded-xl shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <Mail className="h-4.5 w-4.5 text-slate-400" />
                </div>
                <input
                  type="email"
                  placeholder="contacto@mi-laboratorio.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Pie de Página predeterminado de Boleta
              </label>
              <div className="relative rounded-xl shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                  <FileText className="h-4.5 w-4.5 text-slate-400" />
                </div>
                <input
                  type="text"
                  placeholder="Resultados confirmados mediante controles de calidad internacionales."
                  value={reportFooter}
                  onChange={(e) => setReportFooter(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Theme Color Selection and Pricing Panel */}
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-2">
              Personalización de Estilo y Precios
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Theme Selector */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Paleta de Color de la Boleta (Tema Visual)
                </label>
                <p className="text-[10px] text-slate-500 leading-normal">
                  Define el color de acento principal que se aplicará a los encabezados, tablas y líneas divisorias de tus informes PDF.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Navy option */}
                  <label className={`flex items-center gap-2.5 px-3 py-2 border rounded-xl cursor-pointer hover:bg-slate-50/80 transition-all ${themeColor === "navy" ? "border-blue-800 bg-blue-50/25 ring-1 ring-blue-800" : "border-slate-200"}`}>
                    <input
                      type="radio"
                      name="themeColor"
                      value="navy"
                      checked={themeColor === "navy"}
                      onChange={() => setThemeColor("navy")}
                      className="text-blue-800 focus:ring-blue-800 w-3.5 h-3.5 cursor-pointer"
                    />
                    <div className="leading-tight">
                      <span className="text-xs font-extrabold text-slate-800 block">Azul Marino (Torres)</span>
                      <span className="text-[9px] text-blue-800 font-mono font-bold">#0C2D5E Deep Navy</span>
                    </div>
                  </label>

                  {/* Blue option */}
                  <label className={`flex items-center gap-2.5 px-3 py-2 border rounded-xl cursor-pointer hover:bg-slate-50/80 transition-all ${themeColor === "blue" ? "border-sky-500 bg-sky-50/25 ring-1 ring-sky-500" : "border-slate-200"}`}>
                    <input
                      type="radio"
                      name="themeColor"
                      value="blue"
                      checked={themeColor === "blue"}
                      onChange={() => setThemeColor("blue")}
                      className="text-sky-600 focus:ring-sky-500 w-3.5 h-3.5 cursor-pointer"
                    />
                    <div className="leading-tight">
                      <span className="text-xs font-bold text-slate-800 block">Azul Clínico</span>
                      <span className="text-[9px] text-sky-600 font-mono font-bold">#0284C7 Médico</span>
                    </div>
                  </label>

                  {/* Teal option */}
                  <label className={`flex items-center gap-2.5 px-3 py-2 border rounded-xl cursor-pointer hover:bg-slate-50/80 transition-all ${themeColor === "teal" ? "border-teal-500 bg-teal-50/20 ring-1 ring-teal-500" : "border-slate-200"}`}>
                    <input
                      type="radio"
                      name="themeColor"
                      value="teal"
                      checked={themeColor === "teal"}
                      onChange={() => setThemeColor("teal")}
                      className="text-teal-600 focus:ring-teal-500 w-3.5 h-3.5 cursor-pointer"
                    />
                    <div className="leading-tight">
                      <span className="text-xs font-bold text-slate-800 block">Verde Teal (Clásico)</span>
                      <span className="text-[9px] text-teal-600 font-mono font-bold">#0F766E Glacial</span>
                    </div>
                  </label>

                  {/* Purple option */}
                  <label className={`flex items-center gap-2.5 px-3 py-2 border rounded-xl cursor-pointer hover:bg-slate-50/80 transition-all ${themeColor === "purple" ? "border-purple-500 bg-purple-50/20 ring-1 ring-purple-500" : "border-slate-200"}`}>
                    <input
                      type="radio"
                      name="themeColor"
                      value="purple"
                      checked={themeColor === "purple"}
                      onChange={() => setThemeColor("purple")}
                      className="text-purple-600 focus:ring-purple-500 w-3.5 h-3.5 cursor-pointer"
                    />
                    <div className="leading-tight">
                      <span className="text-xs font-bold text-slate-800 block">Púrpura Amatista</span>
                      <span className="text-[9px] text-purple-600 font-mono font-bold">#6D28D9 Elegante</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Pricing catalogs */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-707 uppercase tracking-wider">
                  Catálogo de Aranceles (Precios de Venta)
                </label>
                <p className="text-[10px] text-slate-500 leading-normal">
                  Fija los precios oficiales de venta para cada examen. Esto alimentará la taquilla de ingresos mensuales automáticamente.
                </p>
                <div className="space-y-2 border border-slate-200 rounded-xl p-3 bg-slate-50 max-h-64 overflow-y-auto">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-550 border-b pb-1.5 mb-1.5 uppercase">
                    <span>Examen Clínico</span>
                    <span>Precio (USD $)</span>
                  </div>
                  {[
                    { id: "hemograma", name: "Hemograma Completo" },
                    { id: "ego", name: "General de Orina (EGO)" },
                    { id: "heces", name: "General de Heces" },
                    { id: "quimica_basica", name: "Química Sanguínea" },
                    { id: "perfil_lipidico", name: "Perfil Lipídico" },
                    { id: "perfil_hepatico", name: "Perfil Hepático" },
                    { id: "funcion_renal", name: "Función Renal" },
                    { id: "urocultivo", name: "Urocultivo" },
                    { id: "coprocultivo", name: "Coprocultivo" },
                    { id: "cultivo_faringeo", name: "Cultivo Faríngeo" },
                    { id: "secreciones_varias", name: "Cultivo de Secreciones Varias" },
                    { id: "espermograma", name: "Espermograma Completo" },
                    { id: "miscelaneo", name: "Otros / Examen Especial" }
                  ].map((p) => (
                    <div key={p.id} className="flex justify-between items-center text-xs text-slate-700 py-1 border-b border-slate-100 last:border-none">
                      <span>{p.name}</span>
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-slate-400 font-semibold">$</span>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={examPrices[p.id] ?? 10}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setExamPrices(prev => ({ ...prev, [p.id]: val }));
                          }}
                          className="w-16 text-right px-1.5 py-0.5 border border-slate-300 rounded font-mono text-xs focus:ring-1 focus:ring-teal-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Custom Individual Price override section */}
            <div className="border border-indigo-100 bg-indigo-50/25 p-4 rounded-2xl mt-4">
              <button
                type="button"
                onClick={() => setShowIndividualPrices(!showIndividualPrices)}
                className="flex items-center justify-between w-full text-xs font-black text-indigo-900 uppercase tracking-widest cursor-pointer select-none"
              >
                <span className="flex items-center gap-2">
                  ✨ CONFIGURAR ARANCELES POR EXAMEN INDIVIDUAL ({AVAILABLE_EXAMS.length} Exámenes)
                </span>
                <span className="text-indigo-600 font-bold font-mono">
                  {showIndividualPrices ? "[ OCULTAR PANEL - ]" : "[ VER EXÁMENES + ]"}
                </span>
              </button>
              
              {showIndividualPrices && (
                <div className="mt-4 space-y-4">
                  <p className="text-[10px] text-slate-500 leading-relaxed font-medium">
                    ¿Deseas personalizar el arancel de un examen específico? Digita su nombre abajo para buscarlo y escribe su valor de venta. Si lo dejas vacío o en $0, heredará automáticamente el precio general de su categoría.
                  </p>
                  
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Search className="w-4 h-4 text-slate-400" />
                    </div>
                    <input
                      type="text"
                      placeholder="Buscar por nombre de análisis (ej. Coombs, PCR, PSA, Perfil...)"
                      value={priceSearchQuery}
                      onChange={(e) => setPriceSearchQuery(e.target.value)}
                      className="block w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs bg-white font-medium"
                    />
                  </div>

                  <div className="border border-slate-200 rounded-xl bg-white max-h-64 overflow-y-auto divide-y divide-slate-100 shadow-inner">
                    {AVAILABLE_EXAMS.filter(exam => 
                      exam.name.toLowerCase().includes(priceSearchQuery.toLowerCase()) ||
                      exam.id.toLowerCase().includes(priceSearchQuery.toLowerCase())
                    ).map((exam) => {
                      const customPrice = examPrices[exam.id];
                      return (
                        <div key={exam.id} className="flex justify-between items-center px-4 py-2 hover:bg-slate-50 transition-colors">
                          <div className="flex flex-col pr-4">
                            <span className="text-[11px] font-bold text-slate-800">{exam.name}</span>
                            <span className="text-[8.5px] text-slate-400 font-mono">ID: {exam.id} | Categoría base: {exam.priceKey}</span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-[9px] text-slate-400 font-semibold bg-slate-100 px-1.5 py-0.5 rounded-md">Base: ${exam.defaultPrice}</span>
                            <span className="text-xs text-indigo-700 font-bold">$</span>
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              placeholder={exam.defaultPrice.toFixed(2)}
                              value={customPrice !== undefined ? customPrice : ""}
                              onChange={(e) => {
                                const valStr = e.target.value;
                                if (valStr === "") {
                                  setExamPrices(prev => {
                                    const copy = { ...prev };
                                    delete copy[exam.id];
                                    return copy;
                                  });
                                } else {
                                  const val = parseFloat(valStr) || 0;
                                  setExamPrices(prev => ({ ...prev, [exam.id]: val }));
                                }
                              }}
                              className="w-16 text-right px-2 py-0.5 border border-slate-300 rounded font-mono text-xs focus:ring-1 focus:ring-indigo-500 font-bold bg-white text-indigo-950"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* PROCESSOR AND SIGNATURE SEAL SECTION */}
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-2">
              Validación, Firma y Sello del Laboratorio
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Quién Procesa / Firma
                </label>
                <input
                  type="text"
                  placeholder="ej. Lic. Alejandro K. Orellana"
                  value={processedBy}
                  onChange={(e) => setProcessedBy(e.target.value)}
                  className="block w-full px-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
              
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Título Profesional
                </label>
                <input
                  type="text"
                  placeholder="ej. Licenciado en Laboratorio Clínico"
                  value={processedByTitle}
                  onChange={(e) => setProcessedByTitle(e.target.value)}
                  className="block w-full px-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Registro Profesional / Lic.
                </label>
                <input
                  type="text"
                  placeholder="ej. Reg. J.V.P.L.C. #4591"
                  value={processedByReg}
                  onChange={(e) => setProcessedByReg(e.target.value)}
                  className="block w-full px-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Registro Establecimiento (CSSP)
                </label>
                <input
                  type="text"
                  placeholder="ej. INSCRIPCIÓN CSSP 3085"
                  value={establishmentReg}
                  onChange={(e) => setEstablishmentReg(e.target.value)}
                  className="block w-full px-3 py-2.5 border border-slate-300 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm transition-all"
                />
              </div>
            </div>

            {/* Live Print Simulation Panel */}
            <div className="bg-slate-100 border border-slate-200 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-teal-600" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Simulador Digital de Impresión (Ajuste en Tiempo Real)</span>
                </div>
                <div className="text-[10px] bg-teal-50 text-teal-700 px-2.5 py-0.5 rounded-full font-bold border border-teal-100 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-bounce"></span>
                  Vista Previa Escala 1.7x
                </div>
              </div>
              
              <p className="text-[10.5px] text-slate-600 leading-relaxed">
                Este panel simula exactamente el pie de página que se generará en el archivo PDF de resultados. Use los controles inferiores de ancho, alto y las barras de desplazamiento (Offsets) para mover o redimensionar las imágenes interactivamente. ¡Evita deformaciones usando los botones de proporción!
              </p>

              <div className="flex justify-center py-2.5">
                {/* Simulated physical paper cut-out with millimetric mesh background */}
                <div className="w-[367px] h-32 bg-white rounded-xl shadow-md border border-slate-200 relative overflow-hidden select-none bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:8px_8px]">
                  
                  {/* Left Side: Signature Section */}
                  {/* Signature line at baseline height 82px */}
                  <div className="absolute border-b border-slate-400" id="preview-sig-line" style={{ left: '37px', width: '102px', top: '82px' }} />
                  
                  {/* Signature Image */}
                  {signatureSeal ? (
                    <img
                      src={signatureSeal}
                      alt="Firma"
                      id="preview-sig-img"
                      className="absolute object-contain pointer-events-none transition-all duration-75"
                      referrerPolicy="no-referrer"
                      style={{
                        width: `${sigWidth * 1.7}px`,
                        height: `${sigHeight * 1.7}px`,
                        left: `${37 + (5 * 1.7) + (sigXOffset * 1.7)}px`,
                        top: `${82 - (sigHeight * 1.7) - 3 + (sigYOffset * 1.7)}px`,
                      }}
                    />
                  ) : (
                    <div className="absolute flex items-center justify-center border border-dashed border-slate-300 text-[7px] font-bold text-slate-400 bg-slate-50/50 rounded pointer-events-none"
                         id="preview-sig-none"
                         style={{
                           width: `${sigWidth * 1.7}px`,
                           height: `${sigHeight * 1.7}px`,
                           left: `${37 + (5 * 1.7) + (sigXOffset * 1.7)}px`,
                           top: `${82 - (sigHeight * 1.7) - 3 + (sigYOffset * 1.7)}px`,
                         }}>
                      Sin Firma Cargada
                    </div>
                  )}
                  
                  {/* Under-signature credentials */}
                  <div className="absolute flex flex-col text-left pointer-events-none" id="preview-sig-details" style={{ left: '37px', top: '86px', width: '150px' }}>
                    <span className="text-[7.5px] font-bold text-slate-800 tracking-tight leading-none uppercase truncate">
                      {processedBy ? processedBy.toUpperCase() : "LIC. ALEJANDRO K. ORELLANA"}
                    </span>
                    <span className="text-[6.2px] text-slate-500 font-medium leading-tight mt-0.5 truncate">
                      {processedByTitle || "Licenciado en Laboratorio Clínico"}
                    </span>
                    <span className="text-[6.2px] text-slate-400 leading-none mt-0.5 font-mono truncate">
                      {processedByReg || "Reg. J.V.P.L.C. #4591"}
                    </span>
                  </div>

                  {/* Right Side: Stamp Section */}
                  {labSeal ? (
                    <img
                      src={labSeal}
                      alt="Sello"
                      id="preview-seal-img"
                      className="absolute object-contain pointer-events-none transition-all duration-75"
                      referrerPolicy="no-referrer"
                      style={{
                        width: `${sealWidth * 1.7}px`,
                        height: `${sealHeight * 1.7}px`,
                        left: `${261 + (10 * 1.7) + (sealXOffset * 1.7)}px`,
                        top: `${82 - (sealHeight * 1.7) + (sealYOffset * 1.7)}px`,
                      }}
                    />
                  ) : (
                    <div className="absolute rounded-full border border-dashed border-slate-350 bg-slate-50/40 flex flex-col items-center justify-center pointer-events-none"
                         id="preview-seal-none"
                         style={{
                           width: `${sealWidth * 1.7}px`,
                           height: `${sealHeight * 1.7}px`,
                           left: `${261 + (10 * 1.7) + (sealXOffset * 1.7)}px`,
                           top: `${82 - (sealHeight * 1.7) + (sealYOffset * 1.7)}px`,
                         }}>
                      <span className="text-[5.5px] font-bold text-slate-450 text-center leading-none">Sello</span>
                      <span className="text-[4.5px] font-mono text-slate-350 mt-0.5">{sealWidth}x{sealHeight} mm</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              {/* Lab Seal Card */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 space-y-3" id="lab_seal_config_card">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Sello Oficial de sucursal o firma</span>
                  {labSeal && (
                    <button
                      type="button"
                      onClick={removeLabSeal}
                      className="text-[10px] font-bold text-red-500 hover:underline cursor-pointer"
                    >
                      Remover
                    </button>
                  )}
                </div>
                <p className="text-[10px] text-slate-500 leading-normal">
                  Carga el sello húmedo del laboratorio (ideal fondo blanco o transparente). Esto aparecerá impreso al lado de la firma.
                </p>
                <div className="flex items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-slate-200">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => sealInputRef.current?.click()}
                      className="px-3 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg cursor-pointer transition-colors"
                    >
                      Subir Sello
                    </button>
                    <input
                      type="file"
                      ref={sealInputRef}
                      onChange={handleLabSealUpload}
                      accept="image/png, image/jpeg"
                      className="hidden"
                    />
                  </div>
                  
                  <div className="w-12 h-12 border rounded bg-white flex items-center justify-center overflow-hidden p-0.5">
                    {labSeal ? (
                      <img src={labSeal} alt="Seal preview" className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                    ) : (
                      <span className="text-[7px] text-slate-300 uppercase font-bold text-center">Sin sello</span>
                    )}
                  </div>
                </div>

                {/* Sello metrics setting */}
                <div className="pt-2.5 border-t border-slate-200/60 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Dimensiones del Sello</span>
                    <button
                      type="button"
                      onClick={() => setLockSealRatio(!lockSealRatio)}
                      className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border transition-colors ${
                        lockSealRatio
                          ? "bg-teal-50/50 text-teal-700 border-teal-200"
                          : "bg-slate-100 text-slate-550 border-slate-250"
                      }`}
                      title={lockSealRatio ? "Relación de aspecto bloqueada" : "Relación de aspecto libre"}
                    >
                      {lockSealRatio ? (
                        <>
                          <Link className="w-2.5 h-2.5 text-teal-600" />
                          <span>Proporcional</span>
                        </>
                      ) : (
                        <>
                          <Unlink className="w-2.5 h-2.5 text-slate-450" />
                          <span>Libre</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Proportional Fixer & Presets Button */}
                  {labSeal && (
                    <div className="flex flex-col gap-1.5 bg-white p-2 rounded-lg border border-slate-150">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-semibold text-slate-600">Preajustes sugeridos:</span>
                        <button
                          type="button"
                          onClick={() => {
                            if (!labSeal) return;
                            const img = new Image();
                            img.onload = () => {
                              const ratio = img.width / img.height;
                              setSealRatio(ratio);
                              setSealWidth(25);
                              setSealHeight(Math.round((25 / ratio) * 10) / 10);
                            };
                            img.src = labSeal;
                          }}
                          className="px-2 py-0.5 bg-amber-50 hover:bg-amber-100 text-amber-700 font-bold rounded border border-amber-200 transition-colors"
                        >
                          ⚡ Auto-Ajustar Proporción Real
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setSealWidth(24);
                            setSealHeight(24);
                          }}
                          className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[9px] font-semibold border border-slate-200"
                        >
                          Redondo (24x24)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setSealWidth(30);
                            setSealHeight(30);
                          }}
                          className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[9px] font-semibold border border-slate-200"
                        >
                          Redondo Grande (30x30)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setSealWidth(36);
                            setSealHeight(18);
                          }}
                          className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[9px] font-semibold border border-slate-200"
                        >
                          Oval/Rect (36x18)
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-750">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Ancho (mm)</label>
                      <input
                        type="number"
                        step="1"
                        min="5"
                        max="100"
                        value={sealWidth}
                        onChange={(e) => handleSealWidthChange(Math.max(5, parseFloat(e.target.value) || 25))}
                        className="w-full px-2 py-1 border border-slate-350 rounded bg-white text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-teal-500 font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Alto (mm)</label>
                      <input
                        type="number"
                        step="1"
                        min="5"
                        max="100"
                        value={sealHeight}
                        onChange={(e) => handleSealHeightChange(Math.max(5, parseFloat(e.target.value) || 25))}
                        className="w-full px-2 py-1 border border-slate-350 rounded bg-white text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-teal-500 font-medium"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-0.5">
                        <label className="block text-[9px] uppercase font-bold text-slate-500">Ahoriz. (X Offset)</label>
                        <button
                          type="button"
                          onClick={() => setSealXOffset(0)}
                          className="text-[8px] text-slate-400 hover:text-slate-600 underline font-semibold"
                        >
                          Centrar
                        </button>
                      </div>
                      <div className="flex items-center gap-1">
                        <input
                          type="range"
                          min="-40"
                          max="40"
                          step="1"
                          value={sealXOffset}
                          onChange={(e) => setSealXOffset(parseInt(e.target.value) || 0)}
                          className="w-full accent-teal-600 cursor-pointer h-1 bg-slate-200 rounded-lg appearance-none"
                        />
                        <span className="font-mono text-[9px] font-bold w-6 text-right text-slate-500">{sealXOffset > 0 ? `+${sealXOffset}` : sealXOffset}</span>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-0.5">
                        <label className="block text-[9px] uppercase font-bold text-slate-500">Verti. (Y Offset)</label>
                        <button
                          type="button"
                          onClick={() => setSealYOffset(0)}
                          className="text-[8px] text-slate-400 hover:text-slate-600 underline font-semibold"
                        >
                          Centrar
                        </button>
                      </div>
                      <div className="flex items-center gap-1">
                        <input
                          type="range"
                          min="-40"
                          max="40"
                          step="1"
                          value={sealYOffset}
                          onChange={(e) => setSealYOffset(parseInt(e.target.value) || 0)}
                          className="w-full accent-teal-600 cursor-pointer h-1 bg-slate-200 rounded-lg appearance-none"
                        />
                        <span className="font-mono text-[9px] font-bold w-6 text-right text-slate-500">{sealYOffset > 0 ? `+${sealYOffset}` : sealYOffset}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Signature Seal Card */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 space-y-3" id="signature_config_card">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Firma Digital del Analista</span>
                  {signatureSeal && (
                    <button
                      type="button"
                      onClick={removeSignatureSeal}
                      className="text-[10px] font-bold text-red-500 hover:underline cursor-pointer"
                    >
                      Remover
                    </button>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-normal">
                  Sube tu firma escaneada o fotografiada (tinta negra/azul sobre fondo blanco). Aparecerá posicionada exactamente sobre la línea de firma.
                </p>
                <div className="flex items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-slate-200">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => signatureInputRef.current?.click()}
                      className="px-3 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg cursor-pointer transition-colors"
                    >
                      Subir Firma
                    </button>
                    <input
                      type="file"
                      ref={signatureInputRef}
                      onChange={handleSignatureSealUpload}
                      accept="image/png, image/jpeg"
                      className="hidden"
                    />
                  </div>
                  
                  <div className="w-16 h-10 border rounded bg-white flex items-center justify-center overflow-hidden p-0.5">
                    {signatureSeal ? (
                      <img src={signatureSeal} alt="Signature preview" className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                    ) : (
                      <span className="text-[7px] text-slate-300 uppercase font-bold text-center">Sin firma</span>
                    )}
                  </div>
                </div>

                {/* Firma metrics setting */}
                <div className="pt-2.5 border-t border-slate-200/60 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Dimensiones de Firma</span>
                    <button
                      type="button"
                      onClick={() => setLockSigRatio(!lockSigRatio)}
                      className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border transition-colors ${
                        lockSigRatio
                          ? "bg-teal-50/50 text-teal-700 border-teal-200"
                          : "bg-slate-100 text-slate-550 border-slate-250"
                      }`}
                      title={lockSigRatio ? "Relación de aspecto bloqueada" : "Relación de aspecto libre"}
                    >
                      {lockSigRatio ? (
                        <>
                          <Link className="w-2.5 h-2.5 text-teal-600" />
                          <span>Proporcional</span>
                        </>
                      ) : (
                        <>
                          <Unlink className="w-2.5 h-2.5 text-slate-450" />
                          <span>Libre</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Proportional Fixer & Presets Button */}
                  {signatureSeal && (
                    <div className="flex flex-col gap-1.5 bg-white p-2 rounded-lg border border-slate-150">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-semibold text-slate-600">Preajustes sugeridos:</span>
                        <button
                          type="button"
                          onClick={() => {
                            if (!signatureSeal) return;
                            const img = new Image();
                            img.onload = () => {
                              const ratio = img.width / img.height;
                              setSigRatio(ratio);
                              setSigWidth(45);
                              setSigHeight(Math.round((45 / ratio) * 10) / 10);
                            };
                            img.src = signatureSeal;
                          }}
                          className="px-2 py-0.5 bg-amber-50 hover:bg-amber-100 text-amber-700 font-bold rounded border border-amber-200 transition-colors"
                        >
                          ⚡ Auto-Ajustar Proporción Real
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setSigWidth(45);
                            setSigHeight(14);
                          }}
                          className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[9px] font-semibold border border-slate-200"
                        >
                          Estándar (45x14)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setSigWidth(38);
                            setSigHeight(12);
                          }}
                          className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[9px] font-semibold border border-slate-200"
                        >
                          Compacta (38x12)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setSigWidth(55);
                            setSigHeight(18);
                          }}
                          className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[9px] font-semibold border border-slate-200"
                        >
                          Grande (55x18)
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-750">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Ancho (mm)</label>
                      <input
                        type="number"
                        step="1"
                        min="5"
                        max="100"
                        value={sigWidth}
                        onChange={(e) => handleSigWidthChange(Math.max(5, parseFloat(e.target.value) || 45))}
                        className="w-full px-2 py-1 border border-slate-350 rounded bg-white text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-teal-500 font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Alto (mm)</label>
                      <input
                        type="number"
                        step="1"
                        min="5"
                        max="100"
                        value={sigHeight}
                        onChange={(e) => handleSigHeightChange(Math.max(5, parseFloat(e.target.value) || 14))}
                        className="w-full px-2 py-1 border border-slate-350 rounded bg-white text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-teal-500 font-medium"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-0.5">
                        <label className="block text-[9px] uppercase font-bold text-slate-500">Horiz. (X Offset)</label>
                        <button
                          type="button"
                          onClick={() => setSigXOffset(0)}
                          className="text-[8px] text-slate-400 hover:text-slate-600 underline font-semibold"
                        >
                          Centrar
                        </button>
                      </div>
                      <div className="flex items-center gap-1">
                        <input
                          type="range"
                          min="-40"
                          max="40"
                          step="1"
                          value={sigXOffset}
                          onChange={(e) => setSigXOffset(parseInt(e.target.value) || 0)}
                          className="w-full accent-teal-600 cursor-pointer h-1 bg-slate-200 rounded-lg appearance-none"
                        />
                        <span className="font-mono text-[9px] font-bold w-6 text-right text-slate-500">{sigXOffset > 0 ? `+${sigXOffset}` : sigXOffset}</span>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-0.5">
                        <label className="block text-[9px] uppercase font-bold text-slate-500">Verti. (Y Offset)</label>
                        <button
                          type="button"
                          onClick={() => setSigYOffset(0)}
                          className="text-[8px] text-slate-400 hover:text-slate-600 underline font-semibold"
                        >
                          Centrar
                        </button>
                      </div>
                      <div className="flex items-center gap-1">
                        <input
                          type="range"
                          min="-40"
                          max="40"
                          step="1"
                          value={sigYOffset}
                          onChange={(e) => setSigYOffset(parseInt(e.target.value) || 0)}
                          className="w-full accent-teal-600 cursor-pointer h-1 bg-slate-200 rounded-lg appearance-none"
                        />
                        <span className="font-mono text-[9px] font-bold w-6 text-right text-slate-500">{sigYOffset > 0 ? `+${sigYOffset}` : sigYOffset}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SECCIÓN: GESTIÓN DE USUARIOS CIENTÍFICOS */}
          <div className="bg-slate-50/60 p-5 rounded-2xl border border-slate-200 mt-6 text-left" id="scientific-users-admin-section">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-purple-600" />
              Gestión de Usuarios Científicos y Roles 🧪
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 mb-4 leading-normal">
              Controle quién accede al sistema. Configure cuentas para directivos (CEO, Gerentes) con permisos limitados exclusivamente a consulta de exámenes procesados, cierres de caja y estadísticas.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 font-sans">
              {/* Formulario de Crear Nuevo Usuario */}
              <div className="lg:col-span-5 bg-white p-4.5 rounded-xl border border-slate-150 space-y-3 text-left">
                <h4 className="text-xs font-bold text-purple-950 uppercase tracking-wider">Crear Nuevo Colaborador</h4>
                
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Nombre Completo</label>
                  <input
                    type="text"
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    placeholder="Ej. Licda. María López"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Correo Electrónico</label>
                  <input
                    type="email"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="correo@akolab.com"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-purple-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Contraseña / PIN de Acceso</label>
                  <input
                    type="text"
                    value={newUserPassword}
                    onChange={(e) => setNewUserPassword(e.target.value)}
                    placeholder="PIN numérico o contraseña"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-purple-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Rol y Permisos</label>
                  <select
                    value={newUserRole}
                    onChange={(e: any) => setNewUserRole(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-purple-500 bg-white"
                  >
                    <option value="general">Administrador General (Acceso Total)</option>
                    <option value="ceo">CEO (Solo ver procesados + Estadísticas + Caja)</option>
                    <option value="gerente text-left font-sans">Gerente General (Solo ver procesados + Estadísticas + Caja)</option>
                  </select>
                </div>

                {userAdminError && (
                  <p className="text-[10px] text-red-650 font-semibold bg-red-50 border border-red-100 p-2 rounded-lg">{userAdminError}</p>
                )}

                {userAdminSuccess && (
                  <p className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 border border-emerald-100 p-2 rounded-lg">{userAdminSuccess}</p>
                )}

                <button
                  type="button"
                  onClick={handleAddNewUser}
                  className="w-full py-2 bg-gradient-to-tr from-slate-800 to-indigo-950 hover:from-slate-700 hover:to-indigo-850 text-white text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center justify-center gap-1.5"
                >
                  Registrar Científico
                </button>
              </div>

              {/* Listado de Colaboradores de Laboratorio */}
              <div className="lg:col-span-7 bg-white p-4.5 rounded-xl border border-slate-150 flex flex-col justify-between text-left">
                <div>
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Colaboradores con Acceso</h4>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {usersList.map((usr: any) => {
                      const isMaestro = usr.email === "admin@akolab.com";
                      return (
                        <div key={usr.email} className="flex justify-between items-center p-2.5 rounded-lg border border-slate-100 hover:border-slate-200 transition-colors bg-slate-50/40">
                          <div className="mr-2 min-w-0 text-left">
                            <span className="text-xs font-bold text-slate-800 block truncate leading-tight capitalize">{usr.name}</span>
                            <span className="text-[10px] text-slate-450 font-mono block truncate">{usr.email}</span>
                            <span className="text-[9px] text-slate-400 block font-mono mt-0.5">Clave: {usr.password}</span>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className={`text-[8.5px] px-2 py-0.5 font-bold uppercase rounded-full border ${
                              usr.role === "general"
                                ? "bg-purple-50 text-purple-700 border-purple-250"
                                : usr.role === "ceo"
                                ? "bg-amber-50 text-amber-700 border-amber-250"
                                : "bg-blue-50 text-blue-700 border-blue-250"
                            }`}>
                              {usr.role === "general" ? "Administrador" : usr.role === "ceo" ? "CEO" : "Gerente"}
                            </span>
                            {!isMaestro && (
                              <button
                                type="button"
                                onClick={() => handleDeleteUser(usr.email)}
                                className="p-1 px-1.5 text-slate-400 hover:text-red-700 hover:bg-red-50 border border-slate-200 rounded-lg transition-all"
                                title="Revocar permiso"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                
                <div className="pt-3 border-t border-slate-100 text-[10px] text-slate-500 leading-normal mt-4">
                  💡 <strong>Seguridad de Datos Criptográficos:</strong> Las contraseñas de las cuentas científicas actúan como PINs de derivación y se almacenan de forma segura para permitir cambios fluidos de perfil.
                </div>
              </div>
            </div>
          </div>

          {/* Database Diagnostics and Hosting Real-time Check */}
          <div className="mt-8">
            <DatabaseDiagnostics />
          </div>

          <hr className="border-slate-200 mt-6" />

          {/* Feedback & Actions */}
          {errorStatus && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs font-semibold text-red-600 block">
              {errorStatus}
            </div>
          )}

          {successStatus && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-700 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" /> Perfil guardado e implantado con éxito en la nube de forma cifrada.
            </div>
          )}

          <div className="flex gap-3 justify-end pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 border border-slate-300 hover:bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl cursor-pointer transition-all"
              id="cancel-profile-btn"
            >
              Cerrar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-tr from-slate-800 to-indigo-900 hover:from-slate-700 hover:to-indigo-800 text-white text-sm font-semibold rounded-xl cursor-pointer shadow-md shadow-indigo-900/10 transition-all disabled:opacity-50"
              id="save-profile-btn"
            >
              {isSaving ? "Guardando..." : <><Save className="w-4 h-4" /> Guardar Cambios</>}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
