import React, { useState, useEffect } from "react";
import { KeyRound, ArrowRight, Loader2, Info, Lock, Mail, Users, CheckCircle } from "lucide-react";
import { deriveAuthHash } from "../utils/crypto";
import { getAkoLogoBase64 } from "../utils/akoLogoSvg";

interface LabAuthProps {
  onLoginSuccess: (labId: string, passcode: string, user: { email: string; name: string; role: "general" | "ceo" | "gerente" }) => void;
  onEnterDemoMode: () => void;
}

export default function LabAuth({ onLoginSuccess, onEnterDemoMode }: LabAuthProps) {
  const [emailInput, setEmailInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  
  // Advanced sync configuration drawer
  const [showAdvancedSync, setShowAdvancedSync] = useState(false);
  const [labIdInput, setLabIdInput] = useState("torres");
  const [passcodeInput, setPasscodeInput] = useState("123456789");

  // Pre-seed default user registry in localStorage
  useEffect(() => {
    const defaultUsers = [
      { email: "dricardo.torres23@gmail.com", password: "123456789", name: "Dr. Ricardo Torres", role: "general" }
    ];
    localStorage.setItem("labsync_users_v1", JSON.stringify(defaultUsers));
  }, []);

  const handleQuickLogin = (email: string, pass: string) => {
    setEmailInput(email);
    setPasswordInput(pass);
    setErrorMessage("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");

    if (!emailInput.trim() || !passwordInput.trim()) {
      setErrorMessage("Por favor, ingrese su correo electrónico y contraseña.");
      return;
    }

    setIsLoading(true);

    try {
      // 1. Retrieve the users database
      const usersList = [
        { email: "dricardo.torres23@gmail.com", password: "123456789", name: "Dr. Ricardo Torres", role: "general" }
      ];

      // 2. Validate user credentials (tolerant to case mismatches and trailing/leading spaces from copy-paste)
      const matchedUser = usersList.find((u: any) => {
        const checkEmailInput = emailInput.trim().toLowerCase();
        const checkPassInput = passwordInput.trim();
        const emailMatches = u.email.trim().toLowerCase() === checkEmailInput;
        const passMatches = u.password === checkPassInput || u.password.toLowerCase() === checkPassInput.toLowerCase();
        return emailMatches && passMatches;
      });

      if (!matchedUser) {
        throw new Error("Credenciales inválidas. Verifique su correo electrónico y su contraseña.");
      }

      // 3. Complete login sequence with local cryptographic key derivation
      // We automatically use 'torres' or the designated advanced sync credentials
      const activeLabId = labIdInput.trim().toLowerCase() || "torres";
      // Ensure activePasscode matches the processed password unless advanced is shown
      const activePasscode = showAdvancedSync ? (passcodeInput.trim() || "123456789") : (passwordInput.trim() || "123456789");

      setSuccessMessage(`¡Acreditación exitosa! Bienvenido ${matchedUser.name}...`);
      
      setTimeout(() => {
        onLoginSuccess(activeLabId, activePasscode, {
          email: matchedUser.email,
          name: matchedUser.name,
          role: matchedUser.role as "general" | "ceo" | "gerente"
        });
      }, 1200);

    } catch (err: any) {
      setErrorMessage(err.message || "Fallo al iniciar sesión.");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col lg:flex-row shadow-2xl relative overflow-hidden font-sans" id="lab-auth-root">
      
      {/* LEFT COLUMN: Editorial branding banner with custom responsive SVG illustration */}
      <div className="lg:w-1/2 bg-slate-900 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col justify-center items-center p-8 sm:p-12 relative overflow-hidden">
        {/* Decorative ambient gradients */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-sky-600/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/2 left-1/3 w-[500px] h-32 bg-sky-500/5 rotate-45 rounded-full blur-3xl" />

        <div className="relative z-10 max-w-md w-full text-center space-y-6">
          
          {/* Custom Stylized Logo depicting Laboratorio Clínico Torres official branding */}
          <div className="flex flex-col items-center justify-center mb-2" id="torres-logo-wrapper">
            <img 
              src={getAkoLogoBase64()} 
              className="w-56 h-auto drop-shadow-[0_10px_20px_rgba(37,99,235,0.25)] hover:scale-105 transition-transform duration-500" 
              alt="Laboratorio Clínico Torres Logo" 
              referrerPolicy="no-referrer" 
            />
          </div>

          <div className="space-y-1">
            <h1 className="text-3xl font-black tracking-tight text-white font-sans sm:text-4xl uppercase bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-sky-450 to-emerald-400">
              LABORATORIO CLÍNICO TORRES
            </h1>
            <p className="text-sm font-bold tracking-widest text-slate-300 uppercase font-mono">
              Calidad y Precisión Diagnóstica
            </p>
            <div className="h-1 w-24 bg-gradient-to-r from-blue-500 to-sky-400 mx-auto rounded-full mt-3" />
          </div>

          <p className="text-xs text-slate-400 leading-relaxed max-w-sm mx-auto">
            Sistema Integrado de Recepción de Pacientes, Emisión de Informes Clínicos con Cifrado de Extremo a Extremo, y Dashboard de Control Estadístico.
          </p>
        </div>
      </div>

      {/* RIGHT COLUMN: Stunning login form */}
      <div className="lg:w-1/2 flex flex-col justify-center py-12 px-6 sm:px-12 lg:px-16 bg-slate-950 relative z-20">
        
        <div className="max-w-md w-full mx-auto space-y-8">
          <div>
            <h2 className="text-2xl font-extrabold text-white font-sans tracking-tight">
              Ingreso de Personal Autorizado
            </h2>
            <p className="mt-1.5 text-sm text-slate-400">
              Digite su correo de colaborador asignado por el laboratorio.
            </p>
          </div>

          <form className="space-y-5" onSubmit={handleSubmit} id="torres-auth-form">
            <div>
              <label htmlFor="auth-email" className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                Correo Electrónico
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-4.5 w-4.5 text-slate-500" />
                </div>
                <input
                  id="auth-email"
                  type="email"
                  required
                  placeholder="ej. dricardo.torres23@gmail.com"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="block w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm"
                />
              </div>
            </div>

            <div>
              <label htmlFor="auth-password" className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                Contraseña de Seguridad
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <KeyRound className="h-4.5 w-4.5 text-slate-500" />
                </div>
                <input
                  id="auth-password"
                  type="password"
                  required
                  placeholder="Ingrese su contraseña"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="block w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm"
                />
              </div>
            </div>

            {errorMessage && (
              <div className="bg-red-950/40 border border-red-500/30 rounded-xl p-3.5 text-xs text-red-400 flex items-start gap-2.5" id="auth-error-msg">
                <Info className="w-5 h-5 shrink-0 text-red-500 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {successMessage && (
              <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-3.5 text-xs text-emerald-400 flex items-start gap-2.5">
                <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500 mt-0.5" />
                <span>{successMessage}</span>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full h-12 flex justify-center items-center py-2.5 px-4 border border-transparent rounded-xl shadow-lg shadow-blue-950/20 text-sm font-bold text-white bg-gradient-to-r from-blue-600 to-sky-500 hover:opacity-90 active:scale-[0.98] focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all cursor-pointer disabled:opacity-50"
                id="submit-auth-btn"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin text-white" />
                ) : (
                  <>
                    Iniciar Sesión
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>



          {/* ADVANCED CLOUD CONFIGURATION TRIGGERS */}
          <div className="border-t border-slate-900 pt-5 text-center">
            <button
              type="button"
              onClick={() => setShowAdvancedSync(!showAdvancedSync)}
              className="text-xs text-slate-500 hover:text-slate-350 underline cursor-pointer"
            >
              {showAdvancedSync ? "Ocultar Sincronización Avanzada" : "Sincronización Avanzada (Lab ID / Claves)"}
            </button>

            {showAdvancedSync && (
              <div className="mt-4 p-4 border border-dashed border-slate-800 bg-slate-900/20 rounded-2xl text-left space-y-3.5 animate-fadeIn">
                <div className="flex gap-2 text-xs text-slate-400">
                  <Lock className="w-4 h-4 text-violet-400 mt-0.5 shrink-0" />
                  <p>
                    Edite los datos de abajo si desea que las cuentas accedan a un servidor centralizado específico.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase">Lab ID (Sinc.)</label>
                    <input
                      type="text"
                      value={labIdInput}
                      onChange={(e) => setLabIdInput(e.target.value)}
                      className="mt-1 block w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white uppercase font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase">Contraseña Cifrado</label>
                    <input
                      type="password"
                      value={passcodeInput}
                      onChange={(e) => setPasscodeInput(e.target.value)}
                      className="mt-1 block w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-mono"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
