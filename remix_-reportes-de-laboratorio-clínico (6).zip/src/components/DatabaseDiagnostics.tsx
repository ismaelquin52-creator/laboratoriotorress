import React, { useState, useEffect } from "react";
import { Database, Cpu, Server, Activity, Wifi, CheckCircle2, AlertCircle, RefreshCw, Radio } from "lucide-react";

interface DiagnosticsData {
  isVercel: boolean;
  postgresConfigured: boolean;
  supabaseClientConfigured: boolean;
  activeStorageEngine: "SUPABASE_JS_SDK" | "RAW_POSTGRES_POOL" | "LOCAL_JSON_FILE";
  status: "OK" | "ERROR";
  latencyMs?: number;
  message: string;
}

export default function DatabaseDiagnostics() {
  const [data, setData] = useState<DiagnosticsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDiagnostics = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/db-diagnostics");
      if (!res.ok) {
        throw new Error(`Error de servidor: ${res.statusText}`);
      }
      const json = await res.json();
      setData(json);
    } catch (err: any) {
      setError(err?.message || "Error al conectar con la API de diagnóstico");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDiagnostics();
  }, []);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm text-left" id="database-diagnostics-card">
      {/* Card Header Banner decoration */}
      <div className="bg-slate-50 px-5 py-4 border-b border-slate-150 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800 leading-tight">Diagnóstico de Base de Datos y Servidor</h3>
            <p className="text-[10px] text-slate-400 font-medium">Revisión en tiempo real de la persistencia e infraestructura</p>
          </div>
        </div>
        <button
          type="button"
          onClick={fetchDiagnostics}
          disabled={loading}
          className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-indigo-700 bg-white hover:bg-slate-50 border border-slate-200 hover:border-indigo-200 rounded-lg transition-all cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin text-indigo-600" : ""}`} />
          {loading ? "Revisando..." : "Realizar Test"}
        </button>
      </div>

      <div className="p-5 space-y-4">
        {error && (
          <div className="p-3 bg-red-50 border border-red-150 text-red-600 rounded-xl text-xs flex gap-2.5 items-start">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Error de Conexión:</span> {error}. El servidor web responde pero no pudo consultar con los drivers locales.
            </div>
          </div>
        )}

        {data && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {/* Status Segment */}
            <div className="bg-slate-50/65 p-3.5 rounded-xl border border-slate-100 flex flex-col justify-between">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Estado de Conexión</span>
              <div className="flex items-center gap-2 mt-2">
                {data.status === "OK" ? (
                  <>
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-505 bg-emerald-500"></span>
                    </span>
                    <span className="text-xs font-bold text-slate-800">Activo (Sincronizado)</span>
                  </>
                ) : (
                  <>
                    <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
                    <span className="text-xs font-bold text-red-650">Error de Enlace</span>
                  </>
                )}
              </div>
              <span className="text-[10px] text-slate-450 mt-1 font-semibold leading-relaxed shrink-0">
                {data.message}
              </span>
            </div>

            {/* Persistence Engine Segment */}
            <div className="bg-slate-50/65 p-3.5 rounded-xl border border-slate-100 flex flex-col justify-between">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Motor Activo</span>
              <div className="flex items-center gap-1.5 mt-2 bg-white/80 p-1 px-2.5 border border-slate-205 rounded-lg w-fit text-slate-750 font-mono text-xs font-bold">
                <Radio className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                {data.activeStorageEngine === "SUPABASE_JS_SDK" && "Supabase Client SDK"}
                {data.activeStorageEngine === "RAW_POSTGRES_POOL" && "PostgreSQL Pool TCP"}
                {data.activeStorageEngine === "LOCAL_JSON_FILE" && "Local JSON/Memory File"}
              </div>
              <p className="text-[9.5px] text-slate-400 mt-1 font-medium leading-normal">
                {data.activeStorageEngine === "SUPABASE_JS_SDK" && "Sincroniza registros directo mediante peticiones HTTPS seguras al REST API."}
                {data.activeStorageEngine === "RAW_POSTGRES_POOL" && "Conexión TCP directa mediante socket pool a Base de Datos relacional."}
                {data.activeStorageEngine === "LOCAL_JSON_FILE" && "Backup local preventivo de contingencia activo en el contenedor virtual."}
              </p>
            </div>

            {/* Latency and Hosting Segment */}
            <div className="bg-slate-50/65 p-3.5 rounded-xl border border-slate-100 flex flex-col justify-between">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Hosting e Infraeestructura</span>
              <div className="mt-2 text-xs font-bold text-slate-800 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-450 font-medium">Contenedor Cloud Run / Vercel:</span>
                  <span className="font-mono text-[10px] bg-indigo-50/70 border border-indigo-100/50 text-indigo-700 px-1.5 py-0.5 rounded font-extrabold uppercase">
                    {data.isVercel ? "Vercel Node" : "Cloud Run Core"}
                  </span>
                </div>
                {data.latencyMs !== undefined && (
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-slate-450 font-medium">Latencia Consulta:</span>
                    <span className="font-mono text-[10px] text-slate-600">
                      {data.latencyMs} ms
                    </span>
                  </div>
                )}
              </div>
              <div className="text-[9.5px] text-slate-400 mt-1 leading-normal font-medium">
                La persistencia es escalable y segura bajo cifrado simétrico robusto AES-GCM del lado del cliente.
              </div>
            </div>
          </div>
        )}

        {/* Technical Keys Diagnostic Table */}
        {data && (
          <div className="mt-4 pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">Estado de Variables de Entorno</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-slate-450">DATABASES_URL / SUPABASE_DB_URL</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${data.postgresConfigured ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-amber-550/10 text-amber-600 border border-amber-500/10"}`}>
                  {data.postgresConfigured ? "CONFIGURADA" : "PENDIENTE DE ENLACE"}
                </span>
              </div>
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-slate-450">SUPABASE_URL & ANON_KEY (SDK)</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${data.supabaseClientConfigured ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-amber-550/10 text-amber-600 border border-amber-500/10"}`}>
                  {data.supabaseClientConfigured ? "CONFIGURADA" : "PENDIENTE DE ENLACE"}
                </span>
              </div>
            </div>

            {/* Step-by-step Interactive Supabase Setup Manual */}
            {(!data.postgresConfigured && !data.supabaseClientConfigured) && (
              <div className="mt-4 p-4 rounded-xl border border-teal-100 bg-teal-50/20 text-slate-700 text-xs">
                <div className="flex items-center gap-2 mb-2">
                  <span className="flex h-2 w-2 rounded-full bg-teal-555 bg-teal-500 animate-pulse"></span>
                  <p className="font-extrabold text-[#0D9488] uppercase tracking-wide text-[11px]">Guía Express: Conexión con Supabase</p>
                </div>
                <p className="text-[11px] text-slate-500 leading-normal mb-3">
                  Para guardar y sincronizar pacientes y resultados en tu propia base de datos de <strong>Supabase</strong>, simplemente ingresa una de las siguientes opciones en los Secretos de la plataforma:
                </p>
                <div className="space-y-3 font-sans">
                  <div className="bg-white/90 p-3 rounded-lg border border-slate-100 shadow-sm">
                    <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded uppercase font-mono">Opción Recomendada A (Por Conexión TCP Directa)</span>
                    <p className="mt-1 text-[11px] text-slate-650">Añade la siguiente clave en el panel de secretos:</p>
                    <div className="mt-1.5 font-mono text-[10.5px] p-2 bg-slate-50/60 rounded border border-slate-100 break-all select-all select-text font-bold text-slate-800">
                      SUPABASE_DB_URL=postgres://postgres.[ID_PROYECTO]:[CONTRASENA]@aws-0-us-east-1.pooler.supabase.com:6543/postgres?sslmode=require
                    </div>
                  </div>
                  
                  <div className="bg-white/90 p-3 rounded-lg border border-slate-100 shadow-sm">
                    <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded uppercase font-mono">Opción B (Mediante Cliente HTTP SDK)</span>
                    <p className="mt-1 text-[11px] text-slate-650">Configura estas dos variables en los secretos de la aplicación:</p>
                    <div className="mt-1.5 space-y-1 font-mono text-[10px] text-slate-850 p-2 bg-slate-50/60 rounded border border-slate-100">
                      <div><strong className="text-teal-980">SUPABASE_URL</strong> = https://xxxx.supabase.co</div>
                      <div><strong className="text-teal-980">SUPABASE_KEY</strong> = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (Anon Public Key)</div>
                    </div>
                  </div>
                </div>
                <div className="mt-3.5 flex items-center gap-1 text-[10.5px] text-slate-450">
                  <span>💡</span>
                  <span>Al agregar cualquiera de estas variables, el sistema se conectará y creará las tablas de forma automatizada. No necesitas realizar nada adicional.</span>
                </div>
              </div>
            )}
            
            <p className="text-[10px] text-slate-400 font-medium leading-relaxed mt-2.5 bg-indigo-50/20 border border-indigo-100/30 p-2.5 rounded-lg text-left">
              💬 <strong>Nota de Seguridad:</strong> Todas las bases de datos externas funcionan bajo encapsulado de extremo a extremo (E2E Encrypted AES-GCM) derivando llaves en tu propio navegador. El servidor de base de datos solo almacena bloques altamente cifrados ilegibles para terceros.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
