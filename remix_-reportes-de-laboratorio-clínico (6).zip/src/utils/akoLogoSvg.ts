// High-fidelity SVG representation of LABORATORIO CLÍNICO TORRES branding
export const AKO_LOGO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500" width="800" height="500">
  <defs>
    <!-- Deep Navy to Royal Blue Gradient -->
    <linearGradient id="torresBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#051c3f" />
      <stop offset="40%" stop-color="#0c2d5e" />
      <stop offset="100%" stop-color="#144284" />
    </linearGradient>

    <!-- Vibrant Blue for Liquid -->
    <linearGradient id="liquidGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" />
      <stop offset="50%" stop-color="#0284c7" />
      <stop offset="100%" stop-color="#1e3a8a" />
    </linearGradient>

    <!-- Leaf Green Gradient -->
    <linearGradient id="torresGreenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#4ade80" />
      <stop offset="100%" stop-color="#15803d" />
    </linearGradient>

    <!-- Glass reflections -->
    <linearGradient id="glassReflect" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.6" />
      <stop offset="30%" stop-color="#ffffff" stop-opacity="0.1" />
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
    </linearGradient>
  </defs>

  <!-- ========================================== -->
  <!-- 1. BACKDROP AND SWEEPING ORBITS           -->
  <!-- ========================================== -->
  
  <!-- Outer Blue Orbit Ring (Starts top left, loops back) -->
  <path d="M 330,70 A 180,150 0 1,1 490,280" fill="none" stroke="url(#torresBlueGrad)" stroke-width="6.5" stroke-linecap="round" opacity="0.95" />
  <path d="M 305,80 A 182,152 0 1,1 460,295" fill="none" stroke="url(#torresBlueGrad)" stroke-width="2.5" stroke-linecap="round" opacity="0.4" />

  <!-- Outer Green Orbit / Swoosh (Bottom right transition) -->
  <path d="M 490,280 C 430,340 330,320 280,280 C 230,240 232,180 250,150" fill="none" stroke="url(#torresGreenGrad)" stroke-width="6" stroke-linecap="round" />
  <!-- Underline shadow arc for green sweep -->
  <path d="M 470,290 C 420,335 340,320 295,285" fill="none" stroke="url(#torresGreenGrad)" stroke-width="2.5" stroke-linecap="round" opacity="0.5" />

  <!-- ========================================== -->
  <!-- 2. THE GRAND LETTER "T"                    -->
  <!-- ========================================== -->
  <!-- Serif "T" shape, centered, bold, elegant -->
  <path d="M 345,100 
           L 475,100 
           C 475,115 470,122 458,122 
           L 448,122 
           C 438,122 433,115 433,100 
           L 433,112 
           L 423,112 
           L 423,240 
           L 445,240 
           C 453,240 458,245 458,255 
           L 458,262 
           L 362,262 
           L 362,255 
           C 362,245 367,240 375,240 
           L 397,240 
           L 397,112 
           L 387,112 
           L 387,100 
           C 387,115 382,122 370,122 
           L 360,122 
           C 348,122 345,115 345,100 Z" 
        fill="url(#torresBlueGrad)" 
        filter="drop-shadow(0px 4px 6px rgba(12,45,94,0.25))" />

  <!-- ========================================== -->
  <!-- 3. THE MICROSCOPE (Behind T on the right)  -->
  <!-- ========================================== -->
  <g transform="translate(435, 105)" opacity="0.95">
    <!-- Base -->
    <path d="M 25,120 L 55,120 C 58,120 60,125 58,128 L 54,136 C 52,140 45,142 40,142 L 15,142 C 10,142 5,140 3,136 L -1,128 C -3,125 -1,120 2,120 Z" fill="url(#torresBlueGrad)" />
    <!-- Arm and Joint -->
    <path d="M 38,120 C 45,110 52,90 48,70 C 44,52 30,42 20,40" fill="none" stroke="url(#torresBlueGrad)" stroke-width="7" stroke-linecap="round" />
    <!-- Focus knob -->
    <circle cx="43" cy="98" r="7.5" fill="url(#torresGreenGrad)" stroke="url(#torresBlueGrad)" stroke-width="2" />
    <circle cx="43" cy="98" r="3" fill="#ffffff" />
    <!-- Stage -->
    <line x1="8" y1="85" x2="38" y2="85" stroke="url(#torresBlueGrad)" stroke-width="4.5" stroke-linecap="round" />
    <!-- Substage condenser -->
    <rect x="18" y="90" width="8" height="10" rx="1.5" fill="url(#torresBlueGrad)" />
    <!-- Body tube and Eyepiece -->
    <g transform="rotate(-25, 15, 45)">
      <!-- Eyepiece top -->
      <rect x="11" y="5" width="10" height="6" rx="1" fill="url(#torresBlueGrad)" />
      <!-- Eyepiece tube -->
      <rect x="13" y="11" width="6" height="15" fill="url(#torresBlueGrad)" />
      <!-- Main body tube -->
      <rect x="10" y="26" width="12" height="35" rx="2" fill="url(#torresBlueGrad)" />
      <!-- Nosepiece & Objectives -->
      <path d="M 6,61 L 26,61 L 22,68 L 10,68 Z" fill="url(#torresGreenGrad)" />
      <rect x="10" y="68" width="4" height="10" rx="0.5" fill="url(#torresBlueGrad)" />
      <rect x="18" y="68" width="3" height="7" rx="0.5" fill="url(#torresBlueGrad)" />
    </g>
  </g>

  <!-- ========================================== -->
  <!-- 4. THE TEST TUBE (In front of T on left)  -->
  <!-- ========================================== -->
  <g transform="translate(265, 80)">
    <!-- Liquid content -->
    <rect x="12" y="50" width="26" height="100" rx="13" fill="url(#liquidGrad)" />
    <rect x="12" y="50" width="26" height="40" fill="url(#liquidGrad)" />
    <!-- Liquid Meniscus / Top curve -->
    <ellipse cx="25" cy="50" rx="13" ry="4" fill="#38bdf8" />
    
    <!-- Bubbles in the liquid -->
    <circle cx="20" cy="70" r="2.5" fill="#ffffff" opacity="0.7" />
    <circle cx="30" cy="85" r="3.5" fill="#ffffff" opacity="0.6" />
    <circle cx="18" cy="110" r="1.5" fill="#ffffff" opacity="0.8" />
    <circle cx="28" cy="120" r="2" fill="#ffffff" opacity="0.7" />
    <circle cx="22" cy="135" r="3" fill="#ffffff" opacity="0.5" />

    <!-- Glass Test Tube Outer Outline & Rim -->
    <rect x="10" y="10" width="30" height="142" rx="15" fill="none" stroke="url(#torresBlueGrad)" stroke-width="5" />
    <!-- Collar / Rim at the top -->
    <ellipse cx="25" cy="10" rx="18" ry="4" fill="none" stroke="url(#torresBlueGrad)" stroke-width="5" />
    <ellipse cx="25" cy="10" rx="15" ry="3.5" fill="#ffffff" />
    
    <!-- Glass Highlights/Reflections -->
    <rect x="14" y="18" width="5" height="115" rx="2.5" fill="url(#glassReflect)" />
    <circle cx="25" cy="144" r="7" fill="#ffffff" opacity="0.15" />
  </g>

  <!-- ========================================== -->
  <!-- 5. THREE GREEN LEAVES (Bottom-left)       -->
  <!-- ========================================== -->
  <g transform="translate(225, 205)">
    <!-- Leaf 1 (Leftmost, pointing out) -->
    <path d="M 35,45 C 5,45 -10,15 15,5 C 20,25 30,35 35,45 Z" fill="url(#torresGreenGrad)" stroke="url(#torresBlueGrad)" stroke-width="2" />
    <path d="M 15,5 C 22,20 28,30 35,45" fill="none" stroke="#ffffff" stroke-width="1" opacity="0.4" />

    <!-- Leaf 2 (Middle, pointing up-left) -->
    <path d="M 45,40 C 20,20 25,-10 45,5 C 50,20 48,32 45,40 Z" fill="url(#torresGreenGrad)" stroke="url(#torresBlueGrad)" stroke-width="2" />
    <path d="M 45,5 C 46,18 46,28 45,40" fill="none" stroke="#ffffff" stroke-width="1" opacity="0.4" />

    <!-- Leaf 3 (Right, pointing up) -->
    <path d="M 52,43 C 40,25 50,-2 65,10 C 65,25 60,35 52,43 Z" fill="url(#torresGreenGrad)" stroke="url(#torresBlueGrad)" stroke-width="2" />
    <path d="M 65,10 C 60,22 56,32 52,43" fill="none" stroke="#ffffff" stroke-width="1" opacity="0.4" />
  </g>

  <!-- ========================================== -->
  <!-- 6. BRAND TEXT SECTION (Below Icon)        -->
  <!-- ========================================== -->

  <!-- "— LABORATORIO —" Subtitle -->
  <!-- Flanking lines -->
  <line x1="160" y1="358" x2="250" y2="358" stroke="url(#torresBlueGrad)" stroke-width="3" stroke-linecap="round" />
  <text x="400" y="366" font-family="'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif" font-weight="800" font-size="25" fill="url(#torresBlueGrad)" text-anchor="middle" letter-spacing="10">LABORATORIO</text>
  <line x1="550" y1="358" x2="640" y2="358" stroke="url(#torresBlueGrad)" stroke-width="3" stroke-linecap="round" />

  <!-- "TORRES" Headline (Large, bold, powerful) -->
  <text x="402" y="442" font-family="'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif" font-weight="900" font-size="88" fill="#04152d" text-anchor="middle" letter-spacing="4" opacity="0.15">TORRES</text>
  <text x="400" y="440" font-family="'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif" font-weight="900" font-size="88" fill="url(#torresBlueGrad)" text-anchor="middle" letter-spacing="4">TORRES</text>

  <!-- "— ANÁLISIS CLÍNICOS —" Bottom Tagline -->
  <line x1="170" y1="480" x2="240" y2="480" stroke="url(#torresGreenGrad)" stroke-width="3.5" stroke-linecap="round" />
  <text x="400" y="487" font-family="'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif" font-weight="800" font-size="20" fill="#166534" text-anchor="middle" letter-spacing="8">ANÁLISIS CLÍNICOS</text>
  <line x1="560" y1="480" x2="630" y2="480" stroke="url(#torresGreenGrad)" stroke-width="3.5" stroke-linecap="round" />
</svg>`;

// Helper function to return SVG as an optimized base64 data URI
export function getAkoLogoBase64(): string {
  try {
    return "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(AKO_LOGO_SVG)));
  } catch (e) {
    return "";
  }
}
